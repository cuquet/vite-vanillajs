/* eslint-disable no-undef */
(function() {
    var e = function(e) {
        var l,
            t,
            n;
        this.element = e,
        this.rangeWrapper = this.element.getElementsByClassName("slider__range"),
        this.rangeInput = this.element.getElementsByClassName("slider__input"),
        this.rangeMin = this.rangeInput[0].getAttribute("min"),
        this.rangeMax = this.rangeInput[0].getAttribute("max"),
        this.sliderWidth = window.getComputedStyle(this.element.getElementsByClassName("slider__range")[0]).getPropertyValue("width"),
        this.thumbWidth = getComputedStyle(this.element).getPropertyValue("--slide-thumb-size"),
        t = l = this,
        n = Util.cssSupports("--color-value", "red"),
        !Util.cssSupports("-ms-ime-align", "auto") && n || Util.addClass(t.element, "slider--ms-fallback"),
        s(l),
        l.element.addEventListener("updateRange", function(e) {
            var t,
                n,
                a,
                i;
            t = l,
            n = e.detail,
            a = 0 == n ? 1 : 0,
            i = parseFloat(t.rangeInput[a].value),
            (0 == n && t.rangeInput[0].value >= i || 1 == n && t.rangeInput[1].value <= i) && (t.rangeInput[n].value = i, t.element.dispatchEvent(new CustomEvent("inputRangeLimit", {
                detail: n
            }))),
            s(l)
        }),
        l.element.addEventListener("update-slider-multi-value", function(e) {
            l.sliderWidth = window.getComputedStyle(l.element.getElementsByClassName("slider__range")[0]).getPropertyValue("width"),
            s(l)
        })
    };
    function s(e) {
        var t = parseInt((e.rangeInput[0].value - e.rangeMin) / (e.rangeMax - e.rangeMin) * 100),
            n = parseInt((e.rangeInput[1].value - e.rangeMin) / (e.rangeMax - e.rangeMin) * 100),
            a = "calc(" + t + "*(" + e.sliderWidth + " - 0.5*" + e.thumbWidth + ")/100)",
            i = "calc(" + n + "*(" + e.sliderWidth + " - 0.5*" + e.thumbWidth + ")/100)";
        e.rangeWrapper[0].style.setProperty("--slider-fill-value-start", a),
        e.rangeWrapper[0].style.setProperty("--slider-fill-value-end", i)
    }
    var t,
        n = document.getElementsByClassName("js-slider");
    if (0 < n.length) {
        for (var a = [], i = 0; i < n.length; i++)
            1 < n[t = i].getElementsByClassName("slider__input").length && a.push(new e(n[t]));
        if (0 < a.length) {
            var l = !1,
                r = new CustomEvent("update-slider-multi-value");
            function u() {
                for (var e = 0; e < a.length; e++)
                    a[e].element.dispatchEvent(r)
            }
            window.addEventListener("resize", function() {
                clearTimeout(l),
                l = setTimeout(u, 500)
            })
        }
    }
}());
