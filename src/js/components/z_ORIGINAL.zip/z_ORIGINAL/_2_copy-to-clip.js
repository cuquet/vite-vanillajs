// File#: _2_copy-to-clip
// Usage: codyhouse.co/license
import * as Util from '../utils.js';

(function() {
    class CopyClipboard {
        constructor() {
            this.copyTargetClass = "js-copy-to-clip";
            this.copyStatusClass = "copy-to-clip--copied";
            this.resetDelay = 2000; // delay for removing the copy-to-clip--copied class
            initCopyToClipboard(this);
        }
    }

    function initCopyToClipboard(element) {
        document.addEventListener("click", function(event) {
            var target = event.target.closest("." + element.copyTargetClass);
            if (!target)
                return;
            copyContentToClipboard(element, target);
        });
    }

    function copyContentToClipboard(element, target) {
        // copy to clipboard
        if (navigator.clipboard == undefined) {
            unsecuredUrlCopyTextToClipboard(target);

            // add success class to target
            Util.addClass(target, element.copyStatusClass);

            setTimeout(function () { // remove success class from target
                Util.removeClass(target, element.copyStatusClass);
            }, element.resetDelay);

            // change tooltip content
            var newTitle = target.getAttribute("data-success-title");
            if (newTitle && newTitle != "") target.dispatchEvent(new CustomEvent("newContent", {detail: newTitle}));

            // dispatch success event
            target.dispatchEvent(new CustomEvent("contentCopied"));
            return;
        } else {
            navigator.clipboard.writeText(getContentToCopy(target)).then(function () { // content successfully copied
                // add success class to target
                Util.addClass(target, element.copyStatusClass);

                setTimeout(function () { // remove success class from target
                    Util.removeClass(target, element.copyStatusClass);
                }, element.resetDelay);

                // change tooltip content
                var newTitle = target.getAttribute("data-success-title");
                if (newTitle && newTitle != "") target.dispatchEvent(new CustomEvent("newContent", {detail: newTitle}));

                // dispatch success event
                target.dispatchEvent(new CustomEvent("contentCopied"));
            }, function () { // error while copying the code
                // dispatch error event
                target.dispatchEvent(new CustomEvent("contentNotCopied"));
            });
        }
    }

    function unsecuredUrlCopyTextToClipboard(target) {
        var textArea = document.createElement("textarea");
        textArea.value = target.ariaLabel;

        textArea.style.top = "0";
        textArea.style.left = "0";
        textArea.style.position = "fixed";

        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            document.execCommand("copy");
        } catch (err) {
            console.error("Fallback Error: Unable to copy to clipboard", err);
        }
        document.body.removeChild(textArea);
    }

    function getContentToCopy(target) {
        var content = target.innerHTML;
        var ariaControls = document.getElementById(target.getAttribute("aria-controls")),
            defaultText = target.getAttribute("data-clipboard-content");
        if (ariaControls) {
            content = ariaControls.innerText;
        } else if (defaultText && defaultText != "") {
            content = defaultText;
        }
        return content;
    }

    window.CopyClipboard = CopyClipboard;
    document.addEventListener("DOMContentLoaded", () => {
        var copyToClipboard = document.getElementsByClassName("js-copy-to-clip");
        if (copyToClipboard.length > 0) {
            new CopyClipboard();
        }
    });
}());