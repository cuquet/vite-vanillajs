(function() {
    var e = function(e) {
        this.element = e,
        this.blockWrapper = this.element.getElementsByClassName("js-repeater__list"),
        this.blockWrapper.length < 1 || (this.blocks = !1, s(this), this.firstBlock = !1, this.addNew = this.element.getElementsByClassName("js-repeater__add"), this.cloneClass = this.element.getAttribute("data-repeater-class"), this.inputName = this.element.getAttribute("data-repeater-input-name"), function(l) {
            if (l.addNew.length < 1 || l.blocks.length < 1 || l.blockWrapper.length < 1)
                return;
            l.firstBlock = l.blocks[0].cloneNode(!0),
            l.element.addEventListener("click", function(e) {
                var t = e.target.closest(".js-repeater__remove");
                t && (e.preventDefault(), function(e, t) {
                    var l = t.closest(".js-repeater__item");
                    if (l) {
                        var r = Array.prototype.indexOf.call(e.blocks, l);
                        l.remove(),
                        s(e);
                        for (var a = r; a < e.blocks.length; a++)
                            n(e.blocks[a], e.inputName.replace("[n]", "[" + (a + 1) + "]"), e.inputName.replace("[n]", "[" + a + "]"));
                    }
                }(l, t));
            }),
            l.addNew[0].addEventListener("click", function(e) {
                e.preventDefault(),
                function(e) {
                    if (0 < e.blocks.length)
                        var t = e.blocks[e.blocks.length - 1].cloneNode(!0),
                            l = e.inputName.replace("[n]", "[" + (e.blocks.length - 1) + "]"),
                            r = e.inputName.replace("[n]", "[" + e.blocks.length + "]");
                    else
                        t = e.firstBlock.cloneNode(!0),
                        l = e.inputName.replace("[n]", "[0]"),
                        r = e.inputName.replace("[n]", "[0]");
                    e.cloneClass && t.classList.add(e.cloneClass);
                    n(t, l, r, !0),
                    e.blockWrapper[0].appendChild(t),
                    e.element.dispatchEvent(new CustomEvent("itemCloned", {
                        detail: t
                    })),
                    s(e);
                }(l);
            });
        }(this));
    };
    function n(e, t, l, r) {
        //for (var a = e.querySelectorAll("[name^=\"" + t + "\"]"), n = e.querySelectorAll("[for^=\"" + t + "\"]"), s = e.querySelectorAll("[id^=\"" + t + "\"]"), i = 0; i < a.length; i++) {
        for (var a = e.querySelectorAll("[name^=\"" + t + "\"]"), n = e.querySelectorAll("[for^=\"" + t + "\"]"), s = e.querySelectorAll("[id^=\"" + t + "\"]"), i = 0; i < s.length; i++) {
            //var c = a[i].getAttribute("name");
            var c = s[i].getAttribute("name");
            //a[i].setAttribute("name", c.replace(t, l)),
            s[i].setAttribute("name", c.replace(t, l)),
            //r && ("checkbox" == s[i].type || "radio" == a[i].type ? a[i].checked = !!a[i].getAttribute("data-default") && a[i].getAttribute("data-default") : a[i].value && (a[i].value = a[i].getAttribute("data-default") ? a[i].getAttribute("data-default") : ""));
            r && ("checkbox" == s[i].type || "radio" == s[i].type ? s[i].checked = !!s[i].getAttribute("data-default") && s[i].getAttribute("data-default") : s[i].value && (s[i].value = s[i].getAttribute("data-default") ? s[i].getAttribute("data-default") : ""));
        }
        for (i = 0; i < n.length; i++) {
            var o = n[i].getAttribute("for");
            n[i].setAttribute("for", o.replace(t, l));
        }
        for (i = 0; i < s.length; i++) {
            var u = s[i].getAttribute("id");
            s[i].setAttribute("id", u.replace(t, l));
        }
    }
    function s(e) {
        e.blocks = function(e, t) {
            for (var l = e.children, r = [], a = 0; a < l.length; a++)
                l[a].classList.contains(t) && r.push(l[a]);
            return r;
        }(e.blockWrapper[0], "js-repeater__item");
    }
    var t = document.getElementsByClassName("js-repeater");
    if (0 < t.length)
        for (var l = 0; l < t.length; l++)
            new e(t[l]);
}());