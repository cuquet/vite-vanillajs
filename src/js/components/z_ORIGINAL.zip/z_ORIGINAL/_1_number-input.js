(function() {
    var t = function(t) {
        var e,
            a;
        this.element = t,
        this.input = this.element.getElementsByClassName("js-number-input__value")[0],
        this.min = parseFloat(this.input.getAttribute("min")),
        this.max = parseFloat(this.input.getAttribute("max")),
        this.step = parseFloat(this.input.getAttribute("step")),
        isNaN(this.step) && (this.step = 1),
        this.precision = (e = this.step).toString().length - Math.floor(e).toString().length - 1,
        (a = this).element.addEventListener("click", function(t) {
            var e,
                i,
                n = t.target.closest(".js-number-input__btn");
            n && (t.preventDefault(), e = a, i = n.classList.contains("number-input__btn--plus") ? parseFloat(e.input.value) + e.step : parseFloat(e.input.value) - e.step, 0 < e.precision && (i = i.toFixed(e.precision)), i < e.min && (i = e.min), i > e.max && (i = e.max), e.input.value = i, e.input.dispatchEvent(new CustomEvent("change", {
                bubbles: !0
            })));
        }),
        a.input.addEventListener("focusout", function() {
            var e,
                i,
                n,
                s = parseFloat(a.input.value);
            s < a.min && (s = a.min),
            s > a.max && (s = a.max),
            0 != (n = 10 * (i = s) * (e = a).precision % (10 * e.step * e.precision)) && (i -= n),
            0 < e.precision && (i = i.toFixed(e.precision)),
            (s = i) != parseFloat(a.input.value) && (a.input.value = s);
        });
    };
    window.InputNumber = t;
    var e = document.getElementsByClassName("js-number-input");
    if (0 < e.length)
        for (var i = 0; i < e.length; i++)
            new t(e[i]);
}());
