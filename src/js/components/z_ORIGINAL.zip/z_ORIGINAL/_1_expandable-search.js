//_1_expandable-search

(function() {
    var ExSearch = document.getElementsByClassName("js-expandable-search");
    if (0 < ExSearch.length)
        for (var t = 0; t < ExSearch.length; t++)
            ExSearch[t].getElementsByClassName("js-expandable-search__input")[0].addEventListener("input", function(e) {
                e.target.classList.toggle("expandable-search__input--has-content", 0 < e.target.value.length);
            });
}());
