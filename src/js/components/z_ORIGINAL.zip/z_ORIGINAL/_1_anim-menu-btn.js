/* -------------------------------- 

File#: _1_anim-menu-btn
Title: Animated Menu Button
Descr: Custom Select with advanced structure options.
Usage: https://codyhouse.co/ds/components/info/animated-menu-button
-------------------------------- */

import { tools as Util } from '@modules';

(function() {
    const AnimateButton = document.getElementsByClassName('js-anim-menu-btn');
    if (AnimateButton.length > 0) {
        Array.prototype.forEach.call(AnimateButton, function(element) {
            element.addEventListener('click', function(event) {
                event.preventDefault();
                const e = !Util.hasClass(element, 'anim-menu-btn--state-b');
                Util.toggleClass(element, 'anim-menu-btn--state-b', e);
                event = new CustomEvent('anim-menu-btn-clicked', {
                    detail: e
                });
                element.dispatchEvent(event);
            });
        });
    }
}());
