// File#: _1_modal-window
// Usage: https://codyhouse.co/ds/components/info/modal-window
import Resize from './Resize';
import Drag from './Drag';
import Dialog from '@components/overlays/dialog';
import Button from '@components/button';
import { icons, tools as Util } from '@modules';

function isImgUrl(url) {
    // https://www.zhenghao.io/posts/verify-image-url
    return /\.(jpg|jpeg|png|webp|avif|gif)$/.test(url);
}

class DynamicModal {
    isDynamic;
    modal;
    constructor( element, opts) {
        Object.assign(this, Util.extend(DynamicModal.defaults, opts));
        this.element = element;
        this.isDynamic = (element.hasAttribute('data-content') && !element.hasAttribute('aria-control')) ? true : false;
        this.buildModal();
        //console.log(`Soc DynamicModal => id: ${this.modal.id} => isDynamic: ${this.isDynamic}`);
    }
    buildModal() {
        if(this.isDynamic) {
            this.ID = Util.getNewId();
            this.title = this.element.hasAttribute('data-title') ? this.element.dataset.title : null;
            this.isImage = isImgUrl(this.element.dataset.content);
            this.element.setAttribute('aria-controls','modal-' + this.ID);
            this.modal = this.#renderDynamicModal;
            document.body.appendChild(this.modal);
        } else {
            this.modal = this.element;
        }
    }
    /**
     * Recupera el contingut dinàmic per al modal basat en l'atribut de dades de l'element de desencadenament.
     * 
     * @private perquè no es pot accedir directament des de fora de la classe al posar # davant del nom.
     * @returns {HTMLElement} El contingut generat dinàmicament per al modal.
     */
    get renderDynamicContent() {
        const modalContent = document.createElement('div');
        const modalImage = document.createElement('img');
        var isImage = this.isImage;

        const isHTMLcontent = (v) => {
            var Pattern = new RegExp('<([A-Za-z][A-Za-z0-9]*)\\b[^>]*>(.*?)</\\1>');
            return !!Pattern.test(v);
        };

        const isDOMcontent = (v) => {
            const isSelectorValid = ((dummyElement) => (selector) => {
                try {
                    dummyElement.querySelector(selector);
                } catch {
                    return false;
                }
                return true;
            })(document.createDocumentFragment());

            if (!isSelectorValid(v)) return false;
            var elem = document.querySelector(v);
            if (elem !== null) return true;
            else return elem;
        };

        const isValidUrl = (urlString, base) => {
            let givenURL;
            try {
                givenURL = new URL(urlString, base);
            } catch {
                return false;
            }
            return givenURL.protocol === 'http:' || givenURL.protocol === 'https:';
        };

        const data = this.element.dataset;
        if (isDOMcontent(data.content)) {
            modalContent.innerHTML = document.querySelector(
                data.content,
            ).innerHTML;
        } else {
            if (isHTMLcontent(data.content)) {
                modalContent.innerHTML = data.content;
            } else {
                if (
                    !isValidUrl(data.content) && !isValidUrl(data.content, window.location.origin) &&
                    Util.isString(data.content) && !isImage //!isImgUrl(data.content)
                ) {
                    modalContent.innerText = data.content;
                } else {
                    //console.log('isImage: ', isImgUrl(data.content));
                    const options = {
                        method: 'GET',
                        headers: { 'Access-Control-Allow-Origin': '*' },
                    };

                    const isResponseOk = (response) => {
                        if (!response.ok) {
                            throw new Error(response.status);
                        }
                        if (isImage) {
                            return response.url;
                        }
                        return response.text();
                    };
                    (async () =>
                        await fetch(data.content, options)
                            .then((response) => isResponseOk(response))
                            .then((data) => {
                                if (isImage) {
                                    modalImage.src = data;
                                    modalImage.classList.add(
                                        'radius-md',
                                        'draggable',
                                        'shadow-md',
                                        'max-height-100%',
                                        'max-width-100%',
                                    );
                                    //modalImage.loading = 'lazy';
                                } else {
                                    modalContent.innerHTML = data;
                                }
                            })
                            .catch((err) => {
                                console.error('ERROR ajax: ', err.message);
                                modalContent.innerHTML = err.message;
                            }))();
                }
            }
        }
        setTimeout(() => {
            this.modal.dispatchEvent(new CustomEvent('loadedModal'));
        }, 500);
        return !isImage ? modalContent : modalImage;
    }
    get #renderDynamicFooter() {
        const footer = document.createElement('div');
        Util.addClass(footer, 'modal__footer padding-md');
        const footerActions = document.createElement('div');
        Util.addClass(footerActions, 'flex justify-end gap-xs');
        footer.appendChild(footerActions);

        const Actions = [
            {
                text: 'Tancar',
                type: 'button',
                ariaLabel: 'Tancar modal',
                classes: 'btn btn--subtle',
                onClick: () => {
                    this.handleClose();
                },
            },
        ];

        const c = Actions.concat(this.footerActions);
        c.forEach((action) => {
            const button = new Button(
                action.loading ? 'LoadingButton' : 'TextButton',
                {
                    text: action.text,
                    type: action.type,
                    ariaLabel: action.ariaLabel,
                    classes: action.classes,
                    icon: action.icon ? icons.get(action.icon) : null,
                    onClick: action.onClick,
                },
            );
            footerActions.appendChild(button.get());
            if (action.loading) {
                this.loadingButtons.push(button);
            }
        });
        return footer;
    };
    get #renderDynamicHeader () {
        const header = document.createElement('div');
        Util.addClass(header, this.headerClass);

        const title = document.createElement('h1');
        Util.addClass(title, 'text-truncate text-md');
        title.id = 'modal-title-' + this.ID;
        title.textContent = this.title;

        const actions = document.createElement('div');
        Util.addClass(actions, this.actionsClass);

        const actionsArray = [];
        if (this.headerActions) {
            actionsArray.push(...this.headerActions);
        }
        if (this.fullscreen) {
            actionsArray.push({
                icon: '#expand',
                ariaLabel: 'Pantalla complerta',
                onClick: () => {
                    this.isFullscreen = !this.isFullscreen;
                    Util.toggleClass(this.modal, 'fullscreen', this.isFullscreen);
                    if(this.isFullscreen){
                        this.modal.querySelector('.modal__content').removeAttribute('style');
                    }
                    if (this.onFullscreen) {
                        this.onFullscreen(this.isFullscreen);
                    }
                },
            });
        }
        actionsArray.push({
            icon: '#close',
            ariaLabel: 'Tancar modal',
            classes: 'hide@md'.concat(' ', this.closeClass ),
            onClick: () => {
                this.handleClose();
            }, 
        });
        //}

        if (actionsArray) {
            actionsArray.forEach((action) => {
                const button = new Button('IconButton', {
                    icon: icons.get(action.icon),
                    classes: this.isImage
                        ? this.btnInnerClass
                            .trim()
                            .concat(
                                ' ',
                                this.btnInnerStickyClass,
                                action.classes,
                            )
                        : this.btnInnerClass
                            .trim()
                            .concat(' ', action.classes),
                    buttonSize: 'small',
                    svgSize: 'xs',
                    ariaLabel: action.ariaLabel,
                    onClick: action.onClick,
                });
                actions.appendChild(button.get());
            });
        }
        header.appendChild(title);
        header.appendChild(actions);
        return header;
    }
    /**
     * .
     * 
     * @private perquè no es pot accedir directament des de fora de la classe al posar # davant del nom.
     * @returns {HTMLElement} El contingut generat dinàmicament per al modal.
     */
    get #renderDynamicModal() {
        const modal = document.createElement('div');
        Util.addClass(modal, this.modalClass);
        modal.classList.add(this.animateClass);
        Util.setAttributes(modal, {
            'data-modal-prevent-scroll': this.preventScroll,
            id: 'modal-' + this.ID,
        });

        const content = document.createElement('div');
        Util.setAttributes(content, {
            role: 'alertdialog',
            'aria-labelledby': this.title ? 'modal-title-' + this.ID: '',
            'aria-describedby': '',
        });
        this.contentClass = this.isImage
            ? this.contentClass.concat(' ', this.contentClassImg)
            : this.contentClass.concat(' ', this.contentClassDefault);
        Util.addClass(content, this.contentClass);

        // if (!this.isImage) {
        //     content.style.maxWidth = this.maxWidth + 'px';
        //     content.style.maxHeight = this.maxHeight + 'px';
        // } else {
        //     content.style.maxHeight = '90vh'; //!this.isMobile ? '50%' : '90%';
        // }

        modal.appendChild(content);

        if (this.isFullscreen) {
            //&& !this.isImage) {
            modal.classList.add('fullscreen');
            content.removeAttribute('style');
            // content.style.width = '100%';
            // content.style.height = '100%';
            // content.style.maxHeight = '';
            // content.style.maxWidth = '';
        } else {
            modal.classList.remove('fullscreen');
            //content.style.maxWidth = this.maxWidth + 'px';
            //content.style.maxHeight = this.maxHeight + 'px';
            if (!this.isImage) {
                content.style.maxWidth = this.maxWidth + 'px';
                content.style.maxHeight = this.maxHeight + 'px';
            } else {
                content.style.maxHeight = '90vh'; //!this.isMobile ? '50%' : '90%';
                content.style.margin = 'auto';
            }
        }

        const closeOuterIconButton = new Button('IconButton', {
            icon: icons.get('#close'),
            classes: this.btnOuterClass.concat(' ', this.closeClass ),
            buttonSize: 'small',
            svgSize: 'small',
            ariaLabel: 'Tancar modal',
            onClick: () => {
                this.handleClose();
            }, 
        });
        modal.appendChild(closeOuterIconButton.get());

        if (!this.isImage) {
            content.appendChild(this.#renderDynamicHeader);
            const body = document.createElement('div');
            Util.addClass(body, this.bodyClass);
            content.appendChild(body);
            if (this.footerActions) { //&& !this.isImage)
                content.appendChild(this.#renderDynamicFooter);
            }
        }

        const resize = new Resize({
            el: modal,
            maxWidth: this.maxWidth,
            onResize: (isResize) => {
                drag.isResize = isResize;
            },
        });

        const drag = new Drag({
            el: modal,
            maxWidth: this.maxWidth,
            onDrag: (isDrag) => {
                this.isFullscreen = false;
                resize.isDrag = isDrag;
            },
        });
        return modal;
    }
}

DynamicModal.defaults = {
    animateClass: 'modal--animate-scale',
    //   'modal--animate-scale' default when is empty
    //   'modal--animate-translate-up'
    //   'modal--animate-translate-down'
    //   'modal--animate-translate-right'
    //   'modal--animate-translate-left'
    //   'modal--animate-slide-up'
    //   'modal--animate-slide-down'
    //   'modal--animate-slide-right'
    //   'modal--animate-slide-left'
    modalClass: 'modal flex flex-center flex-wrap bg-black bg-opacity-90% padding-md',
    contentClass: 'modal__content flex',
    contentClassDefault:
        'flex-column flex-nowrap overflow-auto bg radius-md inner-glow shadow-md',
    //contentClassImg:       'flex-column flex-center width-100% height-100% position-absolute pointer-events-none',
    contentClassImg: 'flex-center width-100% height-100% pointer-events-none',
    headerClass:
        'modal__header draggable padding-y-sm padding-x-md flex items-center justify-between flex-shrink-0 bg-contrast-lower bg-opacity-50%',
    actionsClass: 'modal__actions flex flex-row justify-between gap-sm', // 'justify-end flex-shrink-0'
    bodyClass:
        'modal__body padding-y-sm padding-x-md flex-grow overflow-auto momentum-scrolling',
    btnInnerClass: 'modal__close-btn modal__close-btn--inner',
    btnInnerStickyClass: 'float-right position-sticky top-0',
    btnOuterClass:
        'modal__close-btn modal__close-btn--outer js-modal__close',
    headerActions: [],
    footerActions: [],
    loadingButtons: [],
};

class Modal extends DynamicModal{
    constructor( modal, opts = {} ) {
        super(modal, Util.extend(Modal.defaults, opts));
        this.triggers = Array.from(document.querySelectorAll(`[aria-controls= ${this.modal.id}]`));
        this.firstFocusable = null;
        this.lastFocusable = null;
        this.moveFocusEl = null; // focus will be moved to this element when modal is open
        this.modalFocus = (this.modal.dataset.modalFirstFocus)
            ? this.modal.querySelector(this.modal.dataset.modalFirstFocus)
            : null;
//        console.log(`Soc Modal => id: ${this.modal.id} => isDynamic: ${this.isDynamic}`);
//        console.log('this.triggers=>', this.triggers);
//        console.log('this.isImage=>', this.isImage);
        this.init();
    }
    get renderLoader (){
        const modalLoader = document.createElement('div');
        modalLoader.setAttribute('aria-hidden', 'true');
        Util.addClass(modalLoader, 'modal__loader bg-black bg-opacity-90%');
        modalLoader.innerHTML =
            '<svg class="icon icon--lg color-primary icon--is-spinning" ><use href="#spinner"></use></svg>';
        return modalLoader;
    }
    get preventScrollEl () {
        return (this.modal.dataset.modalPreventScroll) ? document.querySelector(this.modal.dataset.modalPreventScroll) : document.querySelector(this.preventScroll);
    }
    isVisible (element) {
        return (
            element.offsetWidth ||
            element.offsetHeight ||
            element.getClientRects().length
        );
    }
    getFocusableElements () {
        //get all focusable elements inside the modal
        //get first visible focusable element inside the modal
        Array.from(this.modal.querySelectorAll(this.focusableElString)).forEach((element) => { 
            if (this.isVisible(element)) {
                this.firstFocusable = element;
                return;
                //break;
            }
        });
        //get last visible focusable element inside the modal
        Array.from(this.modal.querySelectorAll(this.focusableElString)).slice().reverse().forEach((element) => {
            if (this.isVisible(element)) {
                this.lastFocusable = element;
                return;
                //break;
            }
        });
        this.getFirstFocusable();
    }
    getFirstFocusable () {
        if (!this.modalFocus || !Element.prototype.matches) {
            this.moveFocusEl = this.firstFocusable;
            return;
        }
        var containerIsFocusable = this.modalFocus.matches(this.focusableElString);
        if (containerIsFocusable) {
            this.moveFocusEl = this.modalFocus;
        } else {
            this.moveFocusEl = false;
            var elements = this.modalFocus.querySelectorAll(this.focusableElString);
            for (let i = 0; i < elements.length; i += 1) {
                if (this.isVisible(elements[i])) {
                    this.moveFocusEl = elements[i];
                    break;
                }
            }
            if (!this.moveFocusEl) this.moveFocusEl = this.firstFocusable;
        }
    }
    init () {
        if(this.triggers.length > 0){
            this.triggers.forEach((trigger) => {
                trigger.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.selectedTrigger = e.currentTarget;
                    if (this.modal.classList.contains(this.showClass)) {
                        this.close();
                        return;
                    }
                    this.modal.prepend(this.renderLoader);
                    this.modal.classList.add(this.loadingClass);
                    this.loading();
                    this.initEvents();
                });
            });
        }

    }
    initEvents () {
        this.modal.addEventListener('openModal', this.handleOpen.bind(this));
        this.modal.addEventListener('closeModal', this.handleClose.bind(this));

        this.modal.addEventListener('keydown', this.handleKeyDown.bind(this));
        this.modal.addEventListener('click', this.handleClick.bind(this));
        
        //close modal window on esc
        window.addEventListener('keydown', (event) => {
            if (
                (event.keyCode && event.keyCode == 27) ||
                (event.key && event.key.toLowerCase() == 'escape')
            ) {
                this.close();
            }
        });
    }
    loading () {
        this.modal.addEventListener('loadedModal', () => {
            Util.removeClass(this.modal, this.loadingClass);
            document.querySelectorAll('.modal__loader').forEach((el) => el.remove());
            this.modal.dispatchEvent(new CustomEvent('openModal'));
        });
        const documentWidth = document.documentElement.clientWidth;
        this.scrollbarWidth = Math.abs(window.innerWidth - documentWidth);
        if (this.preventScrollEl) {
            this.preventScrollEl.style.overflow = 'hidden';
            this.preventScrollEl.style.paddingRight = `${this.scrollbarWidth}px`;
        }

        this.modal.style.visibility = 'visible';
        this.modal.style.opacity = '1';
        if(!this.isDynamic){
            setTimeout(() => {
                this.modal.dispatchEvent(new CustomEvent('loadedModal'));
            }, 500);
        } else {
            if(!this.isImage){
                const body = this.modal.querySelector('.modal__body');
                body.appendChild(this.renderDynamicContent);
            } else {
                const content = this.modal.querySelector('.modal__content');
                content.appendChild(this.renderDynamicContent);
            }
        }
        this.modal.removeEventListener('loadedModal', (this));
    }
    handleOpen () {
        this.modal.removeAttribute('style');
        Util.addClass(this.modal, this.showClass);
        this.getFocusableElements();
        
        if (this.moveFocusEl) {
            this.moveFocusEl.focus();
            this.modal.addEventListener("transitionend", (event) => {
                this.moveFocusEl.focus();
                this.modal.removeEventListener("transitionend", event.currentTarget);
            });
        }
        
        this.modal.dispatchEvent(new CustomEvent('modalIsOpen', { detail: this.selectedTrigger }));
        if (this.onOpen) { this.onOpen(); }

        this.modal.removeEventListener('openModal', this.handleOpen.bind(this));
    }
    async handleClose (e) {
//        console.log('handleClose=>', e);
        if (e !== undefined) {
            e.preventDefault();
            if( e.target.classList.contains(this.closeClass)) {
                console.log('handleClose=> hasClass');
                this.close();
            }
        }
        if (this.confirmClose) {
            const confirm = new Dialog({
                title: 'Estàs segur que vols tancar finestra?',
                description:
                    'Les dades que no s\'hagin guardat es perdran.',
                accept: 'Tancar',
                cancel: 'Cancel·lar',
                scrollbarWidth: this.scrollbarWidth,
                isDynamic: this.isDynamic
            });
            const confirmResponse = await confirm.question();

            if (!confirmResponse) {
                this.isClose = false;
                return;
            }
        }
        if (this.onClose) { this.onClose(); }
        //this.modal.dispatchEvent(new CustomEvent('modalIsClose'), { detail: this.selectedTrigger });
        this.close();
    }
    handleKeyDown (e) {
//        console.log('handleKeyDown=>', e.target);
        const trapFocus = (event) => {
            if (this.firstFocusable == document.activeElement && event.shiftKey) {
                //on Shift+Tab -> focus last focusable element when focus moves out of modal
                event.preventDefault();
                this.lastFocusable.focus();
            }
            if (this.lastFocusable == document.activeElement && !event.shiftKey) {
                //on Tab -> focus first focusable element when focus moves out of modal
                event.preventDefault();
                this.firstFocusable.focus();
            }
        } 
        if (
            (e.keyCode && e.keyCode == 9) ||
            (e.key && e.key == 'Tab')
        ) {
            //trap focus inside modal
            trapFocus(e);
        } else if (
            ((e.keyCode && event.keyCode == 13) || (e.key && e.key == 'Enter')) &&
            e.target.closest('.js-modal__close')
        ) {
            this.modal.dispatchEvent(new CustomEvent('closeModal'));
            e.preventDefault();
            this.close(); // close modal when pressing Enter on close button
        }
    }
    handleClick (e) {
//        console.log('handleClick=>e', e.target);
        //close modal when clicking on close button or modal bg layer
        if ( !e.target.closest('.'+this.closeClass) && !e.target.classList.contains('js-modal'))
            return;
        e.preventDefault();
        this.close();
    }
    async close () {
        this.loadingButtons.forEach((button) => {
            button.stop();
        });
        document.removeEventListener('closeModal', this.handleClose.bind(this));
        document.removeEventListener('keydown', this.handleKeyDown.bind(this));
        document.removeEventListener('click', this.handleClick.bind(this));

        Util.removeClass(this.modal, this.showClass);
        await Util.transitionend(this.modal);

        if(this.isDynamic && !this.isImage)
            this.modal.querySelector('.modal__body').innerHTML='';
        if(this.isDynamic && this.isImage)
            this.modal.querySelector('.modal__content').innerHTML='';
        if (this.selectedTrigger) this.selectedTrigger.focus();

        this.modal.dispatchEvent(new CustomEvent('modalIsClose'), { detail: this.selectedTrigger });
        if (this.preventScrollEl) this.preventScrollEl.removeAttribute('style');
        delete this;
    }

}

Modal.defaults = {
    preventScroll: 'body',
    loadingClass: 'modal--is-loading',
    showClass: 'modal--is-visible',
    closeClass: 'js-modal__close',
    focusableElString :
    '[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [tabindex]:not([tabindex="-1"]), [contenteditable], audio[controls], video[controls], summary',
    fullscreen: true,
    confirmClose: false,
};

window.Modal = Modal;
export default Modal;

document.addEventListener('DOMContentLoaded', () => {
    var modals = Array.from(document.querySelectorAll('.js-modal.modal'));
    if (modals.length > 0) {
        modals.forEach((element) => {
            new Modal(element,
                {
                    fullscreen: (element.getAttribute('data-fullscreen') && element.dataset.fullscreen == 'off') ? false : true,
                    confirmClose: (element.getAttribute('data-confirm-close') && element.dataset.confirmClose == 'on') ? true : false,
                    onOpen: () => {
                        console.log('Obrir');
                    },
                    onClose: () => {
                        console.log('Tancar');
                    },
                    onFullscreen: (isFullscreen) => {
                        console.log(`Pantalla Complerta: ${isFullscreen}`);
                    },
                }
            );
        });
    }
});
