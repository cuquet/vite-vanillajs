// File#: _1_table
// Usage: https://codyhouse.co/ds/components/info/table
(function() {
    function initTable(table) {
        checkTableLayour(table); // switch from a collapsed to an expanded layout
        table.classList.add("table--loaded"); // show table

        // custom event emitted when window is resized
        table.addEventListener("update-table", function(){
            checkTableLayour(table);
        });
    }

    function checkTableLayour(table) {
        var layout = getComputedStyle(table, ":before").getPropertyValue("content").replace(/\\'|"/g, "");
        table.classList.toggle(tableExpandedLayoutClass, layout != "collapsed");
    }

    var tables = document.getElementsByClassName("js-table"),
        tableExpandedLayoutClass = "table--expanded";
    if( tables.length > 0 ) {
        var j = 0;
        for( var i = 0; i < tables.length; i++) {
            var beforeContent = getComputedStyle(tables[i], ":before").getPropertyValue("content");
            if(beforeContent && beforeContent !="" && beforeContent !="none") {
                (function(i){initTable(tables[i]);})(i);
                j = j + 1;
            } else {
                tables[i].classList.add("table--loaded");
            }
        }
    
        if(j > 0) {
            var resizingId = false,
                customEvent = new CustomEvent("update-table");
            window.addEventListener("resize", function(){
                clearTimeout(resizingId);
                resizingId = setTimeout(doneResizing, 300);
            });
            (window.requestAnimationFrame) ? window.requestAnimationFrame(doneResizing) : doneResizing();
        }
    }
    function doneResizing() {
        for( var i = 0; i < tables.length; i++) {
            (function(i){tables[i].dispatchEvent(customEvent);})(i);
        }
    }
}());
