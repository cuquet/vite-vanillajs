// 2_modal-window-video.js
// https://codyhouse.co/ds/components/info/modal-video
(function() {
    var videoModal = function(e) {
        this.element = e,
        this.modalContent = this.element.getElementsByClassName("js-modal-video__content")[0],
        this.media = this.element.getElementsByClassName("js-modal-video__media")[0],
        this.contentIsIframe = "iframe" == this.media.tagName.toLowerCase(),
        this.modalIsOpen = false,
        this.initModalVideo();
    };
    videoModal.prototype.initModalVideo = function() {
        var self = this;
        this.addLoadListener(),
        this.element.addEventListener("modalIsOpen", function(e) {
            self.modalIsOpen = true,
            self.media.setAttribute("src", e.detail.closest("[aria-controls]").getAttribute("data-url"));
        }),
        this.element.addEventListener("modalIsClose", function() {
            self.modalIsOpen = false,
            self.element.classList.add("modal--is-loading"),
            self.media.setAttribute("src", "");
        });
    },
    videoModal.prototype.addLoadListener = function() {
        var e = this;
        this.contentIsIframe ? this.media.onload = function() {
            e.revealContent();
        } : this.media.addEventListener("loadedmetadata", function() {
            e.revealContent();
        });
    },
    videoModal.prototype.revealContent = function() {
        this.modalIsOpen && (this.element.classList.remove("modal--is-loading"), this.element.getAttribute("data-modal-first-focus") || (this.contentIsIframe ? this.media.contentWindow.focus() : this.media.focus()));
    };
    var videoModals = document.getElementsByClassName("js-modal-video__media");
    if (0 < videoModals.length)
        for (var s = 0; s < videoModals.length; s++)
            new videoModal(videoModals[s].closest(".js-modal"));
}());