//_1_column-table

(function() {
    var e = function(e) {
        var t;
        this.element = e,
        this.header = this.element.getElementsByTagName("thead")[0],
        this.body = this.element.getElementsByTagName("tbody")[0],
        this.headerRows = this.header.getElementsByTagName("th"),
        this.tableRows = this.body.getElementsByTagName("tr"),
        this.mainColCellClass = "cl-table__th-inner",
        function(e) {
            for (var t = [], l = 0; l < e.tableRows.length; l++)
                for (var a = e.tableRows[l].getElementsByClassName("cl-table__cell"), s = 1; s < a.length; s++)
                    0 == l && (t[s] = ""),
                    t[s] = t[s] + "<li class=\"cl-table__item\"><span class=\"cl-table__label\">" + a[0].innerHTML + ":</span><span>" + a[s].innerHTML + "</span></li>";
            for ( s = 1; s < e.headerRows.length; s++) {
                var n = "<input type=\"text\" class=\"cl-table__input\" aria-hidden=\"true\"><span class=\"cl-table__th-inner\">" + e.headerRows[s].innerHTML + "<i class=\"cl-table__th-icon\" aria-hidden=\"true\"></i></span><ul class=\"cl-table__list\" aria-hidden=\"true\">" + t[s] + "</ul>";
                e.headerRows[s].innerHTML = n,
                e.headerRows[s].classList.add("js-" + e.mainColCellClass);
            }
        }(t = this),
        function(e) {
            for (var t = e.header.getElementsByTagName("tr"), l = 0; l < t.length; l++)
                t[l].setAttribute("role", "row");
            // eslint-disable-next-line no-redeclare
            for (var a = e.header.getElementsByTagName("th"), l = 0; l < a.length; l++)
                a[l].setAttribute("role", "cell");
        }(t),
        t.element.addEventListener("click", function(e) {
            l(t, e);
        }),
        t.element.addEventListener("keydown", function(e) {
            (e.keyCode && 13 == e.keyCode || e.key && "enter" == e.key.toLowerCase()) && l(t, e);
        });
    };
    function l(e, t) {
        var l = t.target.closest(".js-" + e.mainColCellClass);
        l && !t.target.closest(".cl-table__list") && l.classList.toggle("cl-table__cell--show-list", !l.classList.contains("cl-table__cell--show-list"));
    }
    var t = document.getElementsByClassName("js-cl-table");
    if (0 < t.length)
        for (var a = 0; a < t.length; a++)
            new e(t[a]);
}());