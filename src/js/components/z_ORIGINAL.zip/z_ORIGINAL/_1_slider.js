(function() {
    var e = function(e) {
        this.element = e,
        this.rangeWrapper = this.element.getElementsByClassName("slider__range"),
        this.rangeInput = this.element.getElementsByClassName("slider__input"),
        this.value = this.element.getElementsByClassName("js-slider__value"),
        this.floatingValue = this.element.getElementsByClassName("js-slider__value--floating"),
        this.rangeMin = this.rangeInput[0].getAttribute("min"),
        this.rangeMax = this.rangeInput[0].getAttribute("max"),
        this.sliderWidth = window.getComputedStyle(this.element.getElementsByClassName("slider__range")[0]).getPropertyValue("width"),
        this.thumbWidth = getComputedStyle(this.element).getPropertyValue("--slide-thumb-size"),
        this.isInputVar = "input" == this.value[0].tagName.toLowerCase(),
        this.isFloatingVar = 0 < this.floatingValue.length,
        this.isFloatingVar && (this.floatingValueLeft = window.getComputedStyle(this.floatingValue[0]).getPropertyValue("left")),
        function(n) {
            l(n),
            r(n, !1),
            s(n, !1),
            e = n,
            t = document.createElement("input"),
            t.setAttribute("type", "range"),
            e.element.classList.toggle("slider--range-not-supported", "range" !== t.type);
            var e,
                t;
            for (var a = 0; a < n.rangeInput.length; a++)
                !function(t) {
                    n.rangeInput[t].addEventListener("input", function() {
                        i(n, t);
                    }),
                    n.rangeInput[t].addEventListener("change", function() {
                        i(n, t);
                    });
                }(a);
            if (n.isInputVar)
                for (a = 0; a < n.value.length; a++)
                    !function(t) {
                        n.value[t].addEventListener("change", function() {
                            u(n, t);
                        });
                    }(a);
            n.element.addEventListener("slider-updated", function() {
                for (var t = 0; t < n.value.length; t++)
                    i(n, t);
            }),
            n.element.addEventListener("inputRangeLimit", function(e) {
                l(n),
                r(n, e.detail);
            });
        }(this);
    };
    function i(e, t) {
        l(e),
        r(e, t),
        s(e, t);
    }
    function l(e) {
        for (var t = 0; t < e.rangeInput.length; t++)
            e.isInputVar ? e.value[t].value = e.rangeInput[t].value : e.value[t].textContent = e.rangeInput[t].value;
    }
    function r(e, t) {
        if (e.isFloatingVar)
            for (var n = t || 0, a = t ? t + 1 : e.rangeInput.length, i = n; i < a; i++) {
                var l = (e.rangeInput[i].value - e.rangeMin) / (e.rangeMax - e.rangeMin);
                e.floatingValue[i].style.left = "calc(0.5 * " + e.floatingValueLeft + " + " + l + " * ( " + e.sliderWidth + " - " + e.floatingValueLeft + " ))";
            }
    }
    function s(e, t) {
        if (1 < e.rangeInput.length)
            e.element.dispatchEvent(new CustomEvent("updateRange", {
                detail: t
            }));
        else {
            var n = (e.rangeInput[0].value - e.rangeMin) / (e.rangeMax - e.rangeMin) * 100,
                a = "calc(" + n + "*(" + e.sliderWidth + " - 0.5*" + e.thumbWidth + ")/100)",
                i = "calc(" + e.sliderWidth + " - " + n + "*(" + e.sliderWidth + " - 0.5*" + e.thumbWidth + ")/100)";
            e.rangeWrapper[0].style.setProperty("--slider-fill-value", a),
            e.rangeWrapper[0].style.setProperty("--slider-empty-value", i);
        }
    }
    function u(e, t) {
        var n = parseFloat(e.value[t].value);
        if (isNaN(n))
            e.value[t].value = e.rangeInput[t].value;
        else {
            n < e.rangeMin && (n = e.rangeMin),
            n > e.rangeMax && (n = e.rangeMax),
            e.rangeInput[t].value = n;
            var a = new Event("change");
            e.rangeInput[t].dispatchEvent(a);
        }
    }
    var t = document.getElementsByClassName("js-slider");
    if (0 < t.length)
        for (var n = 0; n < t.length; n++)
            new e(t[n]);
}());
