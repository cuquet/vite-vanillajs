(function() {
    var t = function(e) {
        var r;
        this.options = n(t.defaults, e),
        this.element = this.options.element,
        this.input = [],
        this.textarea = [],
        this.select = [],
        this.errorFields = [],
        this.errorFieldListeners = [],
        (r = this).input = r.element.querySelectorAll("input"),
        r.textarea = r.element.querySelectorAll("textarea"),
        r.select = r.element.querySelectorAll("select");
    };
    function i(r, t) {
        if (t.checkValidity()) {
            var e = t.getAttribute("data-validate");
            e && r.options.customValidate[e] && r.options.customValidate[e](t, function(e) {
                e || r.errorFields.push(t);
            });
        } else
            r.errorFields.push(t);
    }
    function o(e, r) {
        s(e, r, !0);
        var t = e.errorFieldListeners.length;
        e.errorFieldListeners[t] = function() {
            s(e, r, !1),
            r.removeEventListener("change", e.errorFieldListeners[t]),
            r.removeEventListener("input", e.errorFieldListeners[t]);
        },
        r.addEventListener("change", e.errorFieldListeners[t]),
        r.addEventListener("input", e.errorFieldListeners[t]);
    }
    function s(e, r, t) {
        if (t ? r.classList.add(e.options.inputErrorClass) : r.classList.remove(e.options.inputErrorClass), e.options.inputWrapperErrorClass) {
            var i = r.closest(".js-form-validate__input-wrapper");
            i && (t ? i.classList.add(e.options.inputWrapperErrorClass) : i.classList.remove(e.options.inputWrapperErrorClass));
        }
    }
    t.prototype.validate = function(e) {
        !function(e) {
            e.errorFields = [],
            function(e) {
                for (var r = 0; r < e.errorFields.length; r++)
                    s(e, e.errorFields[r], !1),
                    e.errorFields[r].removeEventListener("change", e.errorFieldListeners[r]),
                    e.errorFields[r].removeEventListener("input", e.errorFieldListeners[r]);
                e.errorFields = [],
                e.errorFieldListeners = [];
            }(e);
            for (var r = 0; r < e.input.length; r++)
                i(e, e.input[r]);
            for (r = 0; r < e.textarea.length; r++)
                i(e, e.textarea[r]);
            for (r = 0; r < e.select.length; r++)
                i(e, e.select[r]);
            for (r = 0; r < e.errorFields.length; r++)
                o(e, e.errorFields[r]);
            0 < e.errorFields.length && e.errorFields[0].focus();
        }(this),
        e && e(this.errorFields);
    };
    var n = function() {
        var t = {},
            i = !1,
            e = 0,
            r = arguments.length;
        "[object Boolean]" === Object.prototype.toString.call(arguments[0]) && (i = arguments[0], e++);
        for (var o = function(e) {
            for (var r in e)
                // eslint-disable-next-line no-undef
                Object.prototype.hasOwnProperty.call(e, r) && (i && "[object Object]" === Object.prototype.toString.call(e[r]) ? t[r] = Util.extend(!0, t[r], e[r]) : t[r] = e[r]);
        }; e < r; e++) {
            o(arguments[e]);
        }
        return t;
    };
    t.defaults = {
        element: "",
        inputErrorClass: "form-control--error",
        inputWrapperErrorClass: "form-validate__input-wrapper--error",
        customValidate: {}
    },
    window.FormValidator = t;
}());