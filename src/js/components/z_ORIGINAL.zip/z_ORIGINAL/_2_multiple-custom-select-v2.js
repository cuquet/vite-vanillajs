(function() {
    var e = function(e) {
        var s;
        this.element = e,
        this.checkboxes = this.element.getElementsByClassName("js-multi-select-v2__input"),
        this.counter = this.element.getElementsByClassName("js-multi-select-v2__selected-items-counter"),
        this.resetBtn = this.element.getElementsByClassName("js-multi-select-v2__reset"),
        this.checkedClass = "multi-select-v2__label--checked",
        l(s = this),
        function(e) {
            for (var t = 0; t < e.checkboxes.length; t++)
                if (e.checkboxes[t].checked) {
                    var s = e.checkboxes[t].closest("label");
                    s && s.classList.add(e.checkedClass);
                }
        }(s),
        s.element.addEventListener("change", function(e) {
            var t = e.target.closest("label");
            t && t.classList.toggle(s.checkedClass, e.target.checked),
            l(s);
        }),
        0 < s.resetBtn.length && s.resetBtn[0].addEventListener("click", function() {
            for (var t = 0; t < s.checkboxes.length; t++)
                s.checkboxes[t].checked = !1;
            l(s, 0),
            function(e) {
                for (var t = e.element.getElementsByClassName(e.checkedClass); t[0];)
                    t[0].classList.remove(e.checkedClass);
            }(s);
        });
    };
    function l(e, t) {
        if (!(e.counter.length < 1))
            if (void 0 === t) {
                for (var s = 0, l = 0; l < e.checkboxes.length; l++)
                    e.checkboxes[l].checked && (s += 1);
                e.counter[0].textContent = s;
            } else
                e.counter[0].textContent = t;
    }
    var t = document.getElementsByClassName("js-multi-select-v2");
    if (0 < t.length)
        for (var s = 0; s < t.length; s++)
            new e(t[s]);
}());
