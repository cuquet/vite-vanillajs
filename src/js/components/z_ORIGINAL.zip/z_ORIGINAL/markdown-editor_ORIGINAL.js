(function() {
    function mdEditor(t, e) {
        this.element = t,
        this.textarea = this.element.getElementsByClassName('js-md-editor__content'),
        this.actionsWrapper = this.element.getElementsByClassName('js-md-editor__actions'),
        this.actions = e || mdEditor.defaults,
        function(e) {
            if (e.textarea.length < 1 || e.actionsWrapper.length < 1)
                return;
            e.actionsWrapper[0].addEventListener('click', function(t) {
                !function(t, e) {
                    if (!e)
                        return;
                    o = t,
                    o.selectionStart = o.textarea[0].selectionStart,
                    o.selectionEnd = o.textarea[0].selectionEnd,
                    o.selectionContent = o.textarea[0].value.slice(o.selectionStart, o.selectionEnd);
                    var o;
                    var i = function(t, e) {
                        var o = function(t, e) {
                            for (var o = [], i = 0; i < Object.keys(t.actions).length; i++)
                                if (t.actions[i].action == e) {
                                    o.push(t.actions[i]),
                                    t.actionEndLength = a(t.actions[i].content);
                                    break
                                }
                            return o
                        }(t, e)[0];
                        if ('' == o.content)
                            return t.selectionContent;
                        o.content.indexOf('content') < 0 && (t.selectionStart = t.selectionStart + t.selectionContent.length, t.selectionContent = '');
                        var i = o.content.replace('content', t.selectionContent);
                        (function(t, e) {
                            if (!e)
                                return !1;
                            if (t.selectionStart < 1)
                                return !1;
                            if (0 < t.selectionStart) {
                                var o = t.textarea[0].value.slice(t.selectionStart - 1, t.selectionStart);
                                return !o.match(/\n/g)
                            }
                            return !0
                        })(t, o.newLine) && (i = '\n' + i);
                        return i
                    }(t, e.getAttribute('data-md-action'));
                    n = t,
                    l = i,
                    r = n.textarea[0].value,
                    n.textarea[0].value = r.slice(0, n.selectionStart) + l + r.slice(n.selectionEnd),
                    n.textarea[0].focus(),
                    n.textarea[0].selectionEnd = n.selectionEnd - n.selectionContent.length + l.length - n.actionEndLength,
                    n.selectionStart != n.selectionEnd ? n.textarea[0].selectionStart = n.textarea[0].selectionEnd - n.selectionContent.length : n.textarea[0].selectionStart = n.textarea[0].selectionEnd;
                    var n,
                        l,
                        r
                }(e, t.target.closest('[data-md-action]'))
            })
        }(this)
    }
    function a(t) {
        var e = t.split('content');
        return e.length < 2 ? 0 : e[1].length;
    }
    mdEditor.defaults = [ 
        {
            action: 'heading',
            content: '###content',
            newLine: !1,
    }, {
        action: 'code',
        content: '`content`',
        newLine: !1,
    }, {
        action: 'link',
        content: '[content](url)',
        newLine: !1,
    }, {
        action: 'blockquote',
        content: '> content',
        newLine: !0,
    }, {
        action: 'bold',
        content: '**content**',
        newLine: !1,
    }, {
        action: 'italic',
        content: '_content_',
        newLine: !1,
    }, {
        action: 'uList',
        content: '- Item 1\n- Item 2\n- Item 3',
        newLine: !0,
    }, {
        action: 'oList',
        content: '1. Item 1\n2. Item 2\n3. Item 3',
        newLine: !0,
    }, {
        action: 'tList',
        content: '- [ ] Item 1\n- [x] Item 2\n- [ ] Item 3',
        newLine: !0,
    }],
    window.mdEditor = mdEditor
}());
