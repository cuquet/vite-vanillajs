//_1_expandable-table

(function() {
    var ExTable = function(e) {
        this.element = e,
        this.rows = this.element.getElementsByClassName("js-ex-table__body")[0].getElementsByTagName("tr"),
        this.labels = this.element.getElementsByClassName("js-ex-table__label"),
        function(o) {
            for (var e = o.element.getElementsByClassName("js-ex-table__btn"), t = 0; t < e.length; t++) {
                var s = !!e[t].closest(".ex-table__row--show-more-content");
                e[t].setAttribute("aria-expanded", s);
            }
            o.element.addEventListener("click", function(e) {
                var t = e.target.closest(".js-ex-table__btn");
                if (t) {
                    var s = t.parentNode.parentNode,
                        n = !s.classList.contains("ex-table__row--show-more-content");
                    s.classList.toggle("ex-table__row--show-more-content", n),
                    t.setAttribute("aria-expanded", n),
                    n || l(o, s, n),
                    function(e) {
                        for (var t = 0; t < e.rows.length; t++)
                            e.rows[t].classList.contains("ex-table__row--show-more-content") && l(e, e.rows[t], !0);
                    }(o);
                }
            });
        }(this);
    };
    function l(e, t, s) {
        var n = t.getElementsByClassName("js-ex-table__more-content");
        0 != n.length && (console.log(e.labels[0].offsetWidth), e.labels[0].offsetWidth <= 0 ? function(e, t, s, n) {
            if (n) {
                for (var o = s.offsetHeight, l = t.children, a = 0; a < l.length; a++)
                    l[a].setAttribute("style", "border-bottom-width:" + o + "px;");
                s.setAttribute("style", "top: " + parseFloat(t.offsetHeight + t.offsetTop - o) + "px;");
            } else
                r(t, s);
        }(0, t, n[0], s) : r(t, n[0]));
    }
    function r(e, t) {
        t.removeAttribute("style");
        for (var s = e.children, n = 0; n < s.length; n++)
            s[n].removeAttribute("style");
    }
    var t = document.getElementsByClassName("js-ex-table");
    if (0 < t.length)
        for (var s = 0; s < t.length; s++)
            new ExTable(t[s]);
}());
