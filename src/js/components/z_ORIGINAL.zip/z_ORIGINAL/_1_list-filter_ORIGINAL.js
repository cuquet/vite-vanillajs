(function() {
    var e = function(e) {
        this.element = e,
        this.search = this.element.getElementsByClassName("js-list-filter__search"),
        this.searchCancel = this.element.getElementsByClassName("js-list-filter__search-cancel-btn"),
        this.list = this.element.getElementsByClassName("js-list-filter__list")[0],
        this.items = this.list.getElementsByClassName("js-list-filter__item"),
        this.noResults = this.element.getElementsByClassName("js-list-filter__no-results-msg"),
        this.searchTags = [],
        this.resultsNr = this.element.getElementsByClassName("js-list-filter__results-nr"),
        this.visibleItemsNr = 0,
        function(s) {
            for (var e = 0; e < s.items.length; e++) {
                var t = "",
                    i = s.items[e].getElementsByClassName("js-list-filter__label");
                0 < i.length && (t = i[0].textContent);
                var l = s.items[e].getAttribute("data-filter-tags");
                l && (t = t + " " + l),
                s.searchTags.push(t);
            }
            r(s, s.search[0].value.trim()),
            s.search[0].addEventListener("input", function() {
                r(s, s.search[0].value.trim());
            }),
            0 < s.searchCancel.length && s.searchCancel[0].addEventListener("click", function() {
                s.search[0].value = "",
                s.search[0].dispatchEvent(new Event("input"));
            });
            s.list.addEventListener("click", function(e) {
                var t = e.target.closest(".js-list-filter__action-btn--remove");
                t && (e.preventDefault(), function(e, t) {
                    var s = t.closest(".js-list-filter__item");
                    if (!s)
                        return;
                    var i = Array.prototype.indexOf.call(e.items, s);
                    s.remove(),
                    e.searchTags.splice(i, 1),
                    e.visibleItemsNr = e.visibleItemsNr - 1,
                    a(e);
                }(s, t));
            });
        }(this);
    };
    function r(e, t) {
        for (var s = [], i = t.toLowerCase().split(" "), l = 0; l < e.items.length; l++)
            "" == t ? s.push(!1) : s.push(n(e, l, i));
        !function(e, t) {
            for (var s = e.visibleItemsNr = 0; s < t.length; s++)
                t[s] || (e.visibleItemsNr = e.visibleItemsNr + 1),
                e.items[s].classList.toggle("hide", t[s]);
            0 < e.noResults.length && e.noResults[0].classList.toggle("hide", 0 < e.visibleItemsNr);
            a(e);
        }(e, s);
    }
    function n(e, t, s) {
        for (var i = !0, l = 0; l < s.length; l++)
            if ("" != s[l] && " " != s[l] && e.searchTags[t].toLowerCase().indexOf(s[l]) < 0) {
                i = !1;
                break;
            }
        return !i;
    }
    function a(e) {
        0 < e.resultsNr.length && (e.resultsNr[0].innerHTML = e.visibleItemsNr);
    }
    var t = document.getElementsByClassName("js-list-filter");
    if (0 < t.length)
        for (var s = 0; s < t.length; s++)
            new e(t[s]);
}());
