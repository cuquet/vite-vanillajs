/* eslint-disable no-undef */
(function() {
    var s = function(s) {
        this.element = s,
        this.password = this.element.getElementsByClassName("js-password__input")[0],
        this.visibilityBtn = this.element.getElementsByClassName("js-password__btn")[0],
        this.visibilityClass = "password--text-is-visible",
        this.initPassword();
    };
    s.prototype.initPassword = function() {
        var t = this;
        this.visibilityBtn.addEventListener("click", function(s) {
            document.activeElement !== t.password && (s.preventDefault(), t.togglePasswordVisibility());
        });
    },
    s.prototype.togglePasswordVisibility = function() {
        var s = !Util.hasClass(this.element, this.visibilityClass);
        Util.toggleClass(this.element, this.visibilityClass, s),
        s ? this.password.setAttribute("type", "text") : this.password.setAttribute("type", "password");
    };
    var t = document.getElementsByClassName("js-password");
    if (0 < t.length)
        for (var i = 0; i < t.length; i++)
            new s(t[i]);
}());
