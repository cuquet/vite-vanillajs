import { tools as Util } from '@modules';

(function() {
    class progressBar {
        constructor(e) {
            var t;
            this.element = e,
            this.fill = this.element.getElementsByClassName('progress-bar__fill')[0],
            this.label = this.element.getElementsByClassName('progress-bar__value'),
            this.value = s(this),
            t = this,
            c && t.element.removeAttribute('data-animation'),
            this.animate = this.element.hasAttribute('data-animation') && 'on' == this.element.getAttribute('data-animation'),
            this.animationDuration = this.element.hasAttribute('data-duration') ? this.element.getAttribute('data-duration') : 1e3,
            this.canAnimate = 'IntersectionObserver' in window && 'IntersectionObserverEntry' in window && 'intersectionRatio' in window.IntersectionObserverEntry.prototype,
            this.ariaLabel = this.element.getElementsByClassName('js-progress-bar__aria-value'),
            this.changeColor = Util.hasClass(this.element, 'progress-bar--color-update') && Util.cssSupports('color', 'var(--color-value)'),
            this.changeColor && (this.colorThresholds = function (e) {
                var t = [], n = 1;
                for (; !isNaN(parseInt(getComputedStyle(e.element).getPropertyValue('--progress-bar-color-' + n)));)
                    t.push(parseInt(getComputedStyle(e.element).getPropertyValue('--progress-bar-color-' + n))),
                        n += 1;
                return t;
            }(this)),
            function (a) {
                a.changeColor && n(a, a.value);
                a.animate && a.canAnimate && (e = a, m(e, 0), new IntersectionObserver(function (e) {
                    var n = this;
                    0 < e[0].intersectionRatio.toFixed(1) && !this.animationTriggered && r(this, 0, this.value, this.animationDuration, function () {
                        o(n, 'progressCompleted', n.value + '%');
                    });
                }.bind(e), {
                    threshold: [0, .1],
                }).observe(e.element));
                var e;
                setTimeout(function () {
                    Util.addClass(a.element, 'progress-bar--init');
                }, 30),
                    a.element.addEventListener('updateProgress', function (e) {
                        a.animationId && window.cancelAnimationFrame(a.animationId);
                        var t = e.detail.value, n = e.detail.duration ? e.detail.duration : a.animationDuration, i = s(a);
                        r(a, i, t, n, function () {
                            o(a, 'progressCompleted', a.value + '%'),
                                0 < a.ariaLabel.length && (a.ariaLabel[0].textContent = t + '%');
                        });
                    });
            }(this),
            this.animationId = !1;
        }
        setProgressBarValue(e) {
            m(this, e);
        }
    }
    function s(e) {
        return parseFloat(100 * e.fill.offsetWidth / e.element.getElementsByClassName('progress-bar__bg')[0].offsetWidth);
    }
    function r(i, a, s, r, o) {
        var l = s - a,
            u = null,
            d = function(e) {
                u || (u = e);
                var t = e - u;
                    var n = parseInt(t / r * l + a);
                0 < l && s < n && (n = s),
                l < 0 && n < s && (n = s),
                r <= t && (n = s),
                m(i, n),
                t < r ? i.animationId = window.requestAnimationFrame(d) : (i.animationId = !1, o());
            };
        window.requestAnimationFrame && !c ? i.animationId = window.requestAnimationFrame(d) : (m(i, s), o());
    }
    function m(e, t) {
        e.fill.style.width = t + '%',
        0 < e.label.length && (e.label[0].textContent = t + '%'),
        e.changeColor && n(e, t);
    }
    function n(e, t) {
        for (var n, i, a = 'progress-bar--fill-color-' + e.colorThresholds.length, s = e.colorThresholds.length; 0 < s; s--)
            !isNaN(e.colorThresholds[s - 1]) && t <= e.colorThresholds[s - 1] && (a = 'progress-bar--fill-color-' + s);
        i = (n = e).element.className.split(' ').filter(function(e) {
            return 0 !== e.lastIndexOf('progress-bar--fill-color-', 0);
        }),
        n.element.className = i.join(' ').trim(),
        Util.addClass(e.element, a);
    }
    function o(e, t, n) {
        e.element.dispatchEvent(new CustomEvent(t, {
            detail: n,
        }));
    }

    window.ProgressBar = progressBar;
    const t = document.getElementsByClassName('js-progress-bar');
    const c = Util.osHasReducedMotion();
    if (t.length > 0) {
        for (let i = 0; i < t.length; i += 1) {
            new progressBar(t[i]);
        }
    }
}());
