/* eslint-disable no-undef */
(function() {
    var e = function(t) {
        this.options = Util.extend(e.defaults, t),
        this.element = this.options.element,
        this.input = this.element.getElementsByClassName("js-password-strength__input"),
        this.reqs = this.element.getElementsByClassName("js-password-strength__req"),
        this.strengthSection = this.element.getElementsByClassName("js-password-strength__meter-wrapper"),
        this.strengthValue = this.element.getElementsByClassName("js-password-strength__value"),
        this.strengthMeter = this.element.getElementsByClassName("js-password-strength__meter"),
        this.passwordInteracted = !1,
        this.reqMetClass = "password-strength__req--met",
        this.reqNoMetClass = "password-strength__req--no-met",
        function(t) {
            t.checkStrength = !0;
            var e = t.element.getAttribute("data-check-strength");
            e && "off" == e && (t.checkStrength = !1);
        }(this),
        function(t) {
            t.checkStrength || (t.strengthLabels = !1);
            t.strengthLabels = ["Bad", "Weak", "Good", "Strong"];
            var e = t.element.getAttribute("data-strength-labels");
            if (e) {
                var s = e.split(",");
                if (s.length < 4)
                    return;
                t.strengthLabels = s.map(function(t) {
                    return t.trim();
                });
            }
        }(this),
        function(t) {
            if (0 == t.input.length)
                return;
            s(t),
            i(t),
            r(t),
            n = t,
            n.input[0].addEventListener("input", function() {
                s(n),
                i(n),
                r(n);
            }),
            n.input[0].addEventListener("blur", function t() {
                n.input[0].removeEventListener("blur", t),
                n.passwordInteracted = !0;
                for (var s = 0; s < n.reqs.length; s++)
                    Util.hasClass(n.reqs[s], n.reqMetClass) || Util.addClass(n.reqs[s], n.reqNoMetClass);
            });
            var n;
        }(this);
    };
    function s(t) {
        0 != t.strengthSection.length && Util.toggleClass(t.strengthSection[0], "hide", 0 == t.input[0].value.length);
    }
    function i(t) {
        if (t.checkStrength && zxcvbn) {
            var e,
                s,
                n = zxcvbn(t.input[0].value);
            if (0 < t.strengthValue.length && (1 <= n.score ? t.strengthValue[0].textContent = t.strengthLabels[n.score - 1] : t.strengthValue[0].textContent = t.strengthLabels[0]), 0 < t.strengthMeter.length) {
                var i = n.score;
                0 == i && 0 < t.input[0].value.length && (i = 1),
                t.strengthMeter[0].firstElementChild.style.width = i / .04 + "%",
                s = (e = t).strengthMeter[0].className.split(" ").filter(function(t) {
                    return 0 !== t.lastIndexOf("password-strength__meter--fill-", 0);
                }),
                e.strengthMeter[0].className = s.join(" ").trim(),
                1 <= n.score ? Util.addClass(t.strengthMeter[0], "password-strength__meter--fill-" + n.score) : Util.addClass(t.strengthMeter[0], "password-strength__meter--fill-1");
            }
        }
    }
    function r(t) {
        for (var e = 0; e < t.reqs.length; e++) {
            var s = t.reqs[e].getAttribute("data-password-req"),
                n = !1;
            n = t.options[s] ? t.options[s](t.input[0].value) : l(t.input[0].value, s),
            Util.toggleClass(t.reqs[e], t.reqMetClass, n),
            t.passwordInteracted && Util.toggleClass(t.reqs[e], t.reqNoMetClass, !n);
        }
    }
    function l(t, e) {
        var s;
        switch (!0) {
        case "uppercase" == e.trim():
            s = t.toLowerCase() != t;
            break;
        case "lowercase" == e.trim():
            s = t.toUpperCase() != t;
            break;
        case "number" == e.trim():
            s = /\d/.test(t);
            break;
        case 0 == e.indexOf("length:"):
            var n = e.split(":");
            s = t.length >= parseInt(n[1]),
            2 < n.length && s && (s = t.length <= parseInt(n[2]));
            break;
        case "special" == e.trim():
            // eslint-disable-next-line no-useless-escape
            s = /[!@#$%^&*=~`'"|/\?\_\-\,\;\.\:\(\)\{\}\[\]\+\>\<\\]/.test(t);
            break;
        case "letter" == e.trim():
            s = /[a-zA-Z]/.test(t);
            break;
        default:
            s = !1;
        }
        return s;
    }
    e.defaults = {
        element: !1
    },
    window.PasswordStrength = e;
    var t = document.getElementsByClassName("js-password-strength");
    if (0 < t.length)
        for (var n = 0; n < t.length; n++)
            new e({
                element: t[n]
            });
}());