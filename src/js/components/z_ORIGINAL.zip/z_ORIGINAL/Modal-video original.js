/* -------------------------------- 

File#: _2_modal-video
Title: Modal Video
Descr: A modal window used to display a responsive video
Usage: https://codyhouse.co/ds/components/info/modal-video
Dependencies
    Modal Window
-------------------------------- */
//import { icons, tools as Util } from '@modules';

/* const isHTMLcontent = (v) => {
    var Pattern = new RegExp('<([A-Za-z][A-Za-z0-9]*)\\b[^>]*>(.*?)</\\1>');
    return !!Pattern.test(v);
};

const isDOMcontent = (v) => {
    const isSelectorValid = ((dummyElement) => (selector) => {
        try {
            dummyElement.querySelector(selector);
        } catch {
            return false;
        }
        return true;
    })(document.createDocumentFragment());

    if (!isSelectorValid(v)) return false;
    var elem = document.querySelector(v);
    if (elem !== null) return true;
    else return elem;
};

const isValidUrl = (urlString, base) => {
    let givenURL;
    try {
        givenURL = new URL(urlString, base);
    } catch {
        return false;
    }
    return givenURL.protocol === 'http:' || givenURL.protocol === 'https:';
};
function isVimeo(url) {
    // https://player.vimeo.com/video/nnnnnnnn
    return /^(http:\/\/|https:\/\/)?(player\.)?(vimeo\.com\/video\/)([0-9]+)$/.test(url);
}
function isYouTube(url){
    // https://www.youtube.com/embed/nnnnnnnn
    return /^(?:https?:\/\/)?(?:m\.|www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/.test(url);
}
const isVideo = (v) => (/\.(mp4|3gp|ogg|wmv|webm|flv|avi*|wav|vob*)$/i).test(v);
const isImage = (v) => (/\.(gif|jpe?g|tiff?|png|webp|bmp)$/i).test(v);
const testImg = (v) => {
    fetch(v, { mode: 'cors', method: 'GET',
        headers: {
            "Accept":"application/json", 
            "Content-Type":"application/json",
        },
    })
    .then(response => {
        console.log(response.headers.get('Content-Type')?.match('image')? true : false);       
    })
    .catch(error => {console.error(error);});
}
async function getMediaType(v) {
    await fetch(v, { mode: 'no-cors', method: 'GET', 
        headers: {
            "Accept":"application/json", 
            "Content-Type":"text/plain",
            //'Access-Control-Allow-Origin': '*'
            //'Access-Control-Allow-Credentials' : 'true',
            //'Access-Control-Allow-Methods' : 'GET',
            //'Access-Control-Allow-Headers': ['Content-Type', 'Authorization'],

            //"Content-type": "application/json;charset=UTF-8"
        },
        //body: "{}"
        //body: JSON.stringify({}) 
    })
    .then(response => console.log(response.headers.get('Content-Type')))
    .catch(error => console.error(error));
}

//const url = "https://picsum.photos/seed/picsum/200/300";
const url = 'https://codyhouse.co/app/assets/video/video-1.mp4';
//const url = 'https://player.vimeo.com/video/308876956';
//const url = 'https://www.youtube.com/embed/t99KH0TR-J4?si=ZmXjmafHH_I2JT1w';

console.log('isVideoUrl',isVideo(url)); // Output: true
console.log('isVimeo',isVimeo(url)); // Output: vimeo
console.log('isYouTube',isYouTube(url)); 
console.log('isImage',isImage(url)); 
//console.log('testImage',testImg(url)); 
//getMediaType(url);
class DynamicModalVideo {
    isDynamic;
    modal;
    constructor( element, opts) {
        Object.assign(this, Util.extend(DynamicModalVideo.defaults, opts));
        this.element = element;
        this.dataOrigin = element.hasAttribute('data-url') || element.hasAttribute('data-content') || null;
        this.mimeType = this.checkMimeType(this.dataOrigin) || 'unknown';
        this.isDynamic = (this.dataOrigin && !element.hasAttribute('aria-control')) ? true : false;
        this.buildModal();
        console.log(`Soc ModalVideoDynamic => id: ${this.modal.id} => isDynamic: ${this.isDynamic} => mimeType: ${this.mimeType}`);
    }
    buildModal() {
        if(this.isDynamic) {
            this.ID = Util.getNewId();
            this.element.setAttribute('aria-controls','modal-' + this.ID);
            this.title = this.element.hasAttribute('data-title') ? this.element.dataset.title : null;
            

            this.modal = this.#renderDynamicModal;
            document.body.appendChild(this.modal);
        } else {
            this.modal = this.element;
        }
    }
    set checkMimeType(url) {
        if(isVimeo(url)) this.mimeType = 'video';
        if(isYouTube(url)) this.mimeType = 'video';
        if(isVideo(url)) this.mimeType = 'video';
        if(isImage(url)) this.mimeType = 'image';
        this.mimeType = 'unknown';
    }
    get #renderDynamicModal() {
        const modal = document.createElement('div');
        modal.id = 'modal-' + this.ID;
        modal.setAttribute('aria-hidden', 'true');
        modal.setAttribute('class', 'modal ' + this.animateClass);
        modal.innerHTML = `
            <div class="${this.modalClass}">
                <div class="${this.contentClass}">
                    <header class="${this.headerClass}">
                        <h2 class="modal__title">${this.title}</h2>
                        <button class="${this.btnOuterClass}" aria-label="Close modal">
                            <span class="${this.btnInnerClass}">${icons.close}</span>
                        </button>
                    </header>
                    
                        ${this.#getModalContent}
                    </div>
                </div>
            </div>
        `;
        return modal;
    }
    get #getModalContent() {
        if(this.mimeType === 'image') {
            return `
                <div class="${this.bodyClass}">
                    <img src="${this.element.dataset.content}" alt="Image" class="${this.contentClassImg}">
                    </div>`;
        }
        if(this.mimeType === 'video') {
            return `<video src="${this.element.dataset.content}" class="${this.contentClassVideo}" controls></video>`;
        }
        if(this.mimeType === 'vimeo') {
            return `<iframe src="${this.element.dataset.content}" class="${this.contentClassVideo}" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
        }
        if(this.mimeType === 'youtube') {
            return `<iframe src="${this.element.dataset.content}" class="${this.contentClassVideo}" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
        }
        return `<div class="${this.contentClassDefault}">${this.element.dataset.content}</div>`;
    }

}

DynamicModalVideo.defaults = {
    animateClass: 'modal--animate-scale',
    //   'modal--animate-scale' default when is empty
    //   'modal--animate-translate-up'
    //   'modal--animate-translate-down'
    //   'modal--animate-translate-right'
    //   'modal--animate-translate-left'
    //   'modal--animate-slide-up'
    //   'modal--animate-slide-down'
    //   'modal--animate-slide-right'
    //   'modal--animate-slide-left'
    modalClass: 'modal flex flex-center flex-wrap bg-black bg-opacity-90% padding-md' /*padding-x-md js-modal*//* ,
    contentClass: 'modal__content',
    contentClassDefault:
        ' flex flex-column flex-nowrap overflow-auto bg radius-md inner-glow shadow-md',
    contentClassImg: ' flex flex-center width-100% height-100% pointer-events-none',
    //contentClassImg: 'flex-column flex-center width-100% height-100% position-absolute pointer-events-none',
    contentClassVideo: ' width-100% max-width-md max-height-100% overflow-auto shadow-md',
    headerClass:
        'modal__header draggable padding-y-sm padding-x-md flex items-center justify-between flex-shrink-0 bg-contrast-lower bg-opacity-50%',
    actionsClass: 'modal__actions flex flex-row justify-between gap-sm', // 'justify-end flex-shrink-0'
    bodyClass:
        'modal__body padding-y-sm padding-x-md flex-grow overflow-auto momentum-scrolling',
    btnInnerClass: 'modal__close-btn modal__close-btn--inner',
    btnInnerStickyClass: 'float-right position-sticky top-0',
    btnOuterClass:
        'modal__close-btn modal__close-btn--outer js-modal__close',
    headerActions: [],
    footerActions: [],
    loadingButtons: [],
};
 */
class ModalVideo {
    constructor(element) {
        this.element = element;
        this.modalContent = this.element.getElementsByClassName('js-modal-video__content')[0];
        this.media = this.element.getElementsByClassName('js-modal-video__media')[0];
        this.contentIsIframe = this.media.tagName.toLowerCase() === 'iframe';
        this.modalIsOpen = false;
        this.init();
        //console.log(this.media);
    }

    init() {
        this.addLoadListener();
        this.element.addEventListener('modalIsOpen', (e) => {
            this.modalIsOpen = true;
            this.media.setAttribute(
                'src',
                e.detail.closest('[aria-controls]').getAttribute('data-url'),
            );
            console.log(e.detail.closest('[aria-controls]').getAttribute('data-url'));
            console.log(this.media.getAttribute('src'));
        });
        this.element.addEventListener('modalIsClose', () => {
            this.modalIsOpen = false;
            this.element.classList.add('modal--is-loading');
            this.media.setAttribute('src', '');
        });
        // this.element.onClose = () => {
        //     this.modalIsOpen = false;
        //     this.element.classList.add('modal--is-loading');
        //     this.media.setAttribute('src', '');
        //     console.log('onClose');
        // }
    }

    addLoadListener() {
        if (this.contentIsIframe) {
            this.media.onload = () => {
                this.revealContent();
            };
        } else {
            this.media.addEventListener('loadedmetadata', () => {
                this.revealContent();
            });
        }
    }

    revealContent() {
        if (this.modalIsOpen) {
            this.element.classList.remove('modal--is-loading');
            if (!this.element.getAttribute('data-modal-first-focus')) {
                if (this.contentIsIframe) {
                    this.media.contentWindow.focus();
                    // console.log(this.media.contentWindow);
                } else {
                    this.media.focus();
                    // console.log(this.media);
                }
            }
        }
    }
}

export default ModalVideo;

document.addEventListener('DOMContentLoaded', () => {
    const videoModals = document.getElementsByClassName('js-modal-video__media');
    if (videoModals.length > 0) {
        for (let i = 0; i < videoModals.length; i++) {
            new ModalVideo(videoModals[i].closest('.js-modal'));
            //console.log(videoModals[i]);
            //console.log(videoModals[i].closest('.js-modal'));
        }
    }
});
