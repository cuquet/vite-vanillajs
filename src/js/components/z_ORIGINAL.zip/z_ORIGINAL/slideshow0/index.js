import Slideshow from "./classes/slideshow";
export default Slideshow;
