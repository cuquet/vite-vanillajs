(function() {
    /*
     Loading animation class
    modal--animate-fade: animate the opacity
    modal--animate-scale: scale up the modal content
    modal--animate-translate-up: translate up the modal content
    modal--animate-translate-down: translate down the modal content
    modal--animate-translate-right: translate right the modal content
    modal--animate-translate-left: translate left the modal content
    modal--animate-slide-up: translate up the modal content by 100% of its height (use for content moving in/out the viewport)
    modal--animate-slide-down: translate down the modal content by 100% of its height
    modal--animate-slide-right: translate right the modal content by 100% of its width
    modal--animate-slide-left: translate left the modal content by 100% of its width
    */
    const modalAnimateClass             = "modal--animate-scale";
    const modalContainerClass           = "modal modal--is-loading flex flex-center bg-black bg-opacity-90% padding-md js-modal";
    const modalHeaderClass              = "bg-contrast-lower bg-opacity-50% padding-y-sm padding-x-md flex items-center justify-between flex-shrink-0";
    const modalImageClass               = "radius-md shadow-md max-height-100% max-width-100%";
    const modalContentClassWithHeader   = "modal__content width-100% max-width-md max-height-100% overflow-auto bg radius-md inner-glow shadow-md flex flex-column";
    const modalContentClassWithoutHeader= "modal__content width-100% max-width-md max-height-100% overflow-auto bg radius-md inner-glow shadow-md padding-md";
    const modalContentClassImage        = "modal__content width-100% height-100% flex flex-center pointer-events-none";
    const closeInnerClassSticky         = "modal__close-btn modal__close-btn--inner hide@md float-right position-sticky top-0 js-modal__close";
    const closeInnerClass               = "modal__close-btn modal__close-btn--inner hide@md js-modal__close";
    const closeOuterClass               = "modal__close-btn modal__close-btn--outer display@md js-modal__close" ;
    
    // https://www.zhenghao.io/posts/verify-image-url
    function isImgUrl(url) {
        return /\.(jpg|jpeg|png|webp|avif|gif)$/.test(url);
    }
    /*const isImgUrl = v => {
        const img = new Image();
        img.src = v;
        return new Promise((resolve) => {
            img.onerror = () => resolve(false);
            img.onload = () => resolve(true);
        });
    };*/

    /*const isValidUrl = v => {
        var Pattern = new RegExp("^(https?:\\/\\/)?"+ // validate protocol
      "((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|"+ // validate domain name
      "((\\d{1,3}\\.){3}\\d{1,3}))"+ // validate OR ip (v4) address
      "(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*"+ // validate port and path
      "(\\?[;&a-z\\d%_.~+=-]*)?"+ // validate query string
      "(\\#[-a-z\\d_]*)?$","i"); // validate fragment locator
        return !!Pattern.test(v);
    };*/


    const isHTMLcontent = v => {
        var Pattern = new RegExp("<([A-Za-z][A-Za-z0-9]*)\\b[^>]*>(.*?)</\\1>");
        return !!Pattern.test(v);
    };

    const isSelectorValid = ((dummyElement) =>
        (selector) => {
            try { dummyElement.querySelector(selector); } catch { return false; }
            return true;
        })(document.createDocumentFragment());

    const isDOMcontent = v => {
        if(!isSelectorValid(v))
            return false;
        var elem = document.querySelector(v);
        if(elem !==null)
            return true;
        else
            return elem;
    };


    function initDynamicDialog(modalId, setTitle = false, isImage = false){
        var modalContainer = document.createElement("div"),
            modalHeader = document.createElement("header"),
            modalImage =  document.createElement("img"),
            modalContent = document.createElement("div"),
            modalLoader = document.createElement("div"),
            modalCloseIn = document.createElement("button"),
            modalCloseOut = document.createElement("button");

        modalContainer.setAttribute("id", modalId);
        modalContainer.className = modalContainerClass;
        modalContainer.setAttribute("data-modal-prevent-scroll", "body");

        modalHeader.className = modalHeaderClass;

        modalImage.className = modalImageClass;
        
        modalContent.setAttribute("role","alertdialog");
        modalContent.setAttribute("aria-describedby","description-" + modalId);
        

        modalCloseIn.className = closeInnerClassSticky;
        modalCloseIn.innerHTML = "<svg class=\"icon icon--xs\" ><use href=\"#close\"></use></svg>";

        modalCloseOut.className = closeOuterClass;
        modalCloseOut.innerHTML = "<svg class=\"icon icon--sm border-primary\" ><use href=\"#close-lg\"></use></svg>";
        
        if (setTitle) {
            modalContent.setAttribute("aria-labelledby","title" + modalId);
            modalContent.className = modalContentClassWithHeader;
            (isImage) ? modalContent.className =  modalContentClassImage : modalContent.className =  modalContentClassWithHeader;
            modalHeader.innerHTML = "<h1 id=\"title-" + modalId + "\" class=\"text-truncate text-md\"></h1>";
            modalHeader.appendChild(modalCloseIn).className = closeInnerClass;
            modalContent.appendChild(modalHeader);
        } else {
            (isImage) ? modalContent.className =  modalContentClassImage : modalContent.className =  modalContentClassWithoutHeader;
            modalContent.appendChild(modalCloseIn);
        }
        
        

        modalLoader.setAttribute("aria-hidden","true");
        modalLoader.className = "modal__loader";
        modalLoader.innerHTML = "<svg class=\"icon icon--lg color-bg icon--is-spinning\" ><use href=\"#spinner\"></use></svg>";

        (isImage) ? modalContent.appendChild(modalImage)  : modalContent.insertAdjacentHTML( "beforeend", "<div class=\"padding-y-sm padding-x-md flex-grow overflow-auto momentum-scrolling\"><div class=\"text-component\"></div>" );
        //(!isImage) ? modalContent.insertAdjacentHTML( "beforeend", "<div class=\"padding-y-sm padding-x-md flex-grow overflow-auto momentum-scrolling\"><div class=\"text-component\"></div>" ) : modalContent.insertAdjacentHTML( "beforeend", "<img src=\"\" class=\""+ modalImageClass + "\">" ); 
        modalContainer.appendChild(modalContent);
        modalContainer.appendChild(modalLoader);
        modalContainer.appendChild(modalCloseOut).className = closeOuterClass;
        document.body.appendChild(modalContainer);
        // eslint-disable-next-line no-undef
        new Modal(document.getElementById(modalId));
    }
    
    var modalButtons = document.getElementsByClassName("js-modal-btn");
    
    if (0 < modalButtons.length)
        for (var s = 0; s < modalButtons.length; s++) {
            modalButtons[s].addEventListener("click", (e) => {
                let dialog, dialogContent, dialogTitleText, modalDynamic = false, data = e.target.dataset, isImage = false  ;
                const dialogId = (e.target.hasAttribute("data-target")) ? data.target : "modal-" + Date.now();
                if (document.getElementById(dialogId) == null) {
                    modalDynamic = true;
                    dialogTitleText = (e.target.hasAttribute("data-title")) ? data.title : null;
                    initDynamicDialog(dialogId, (dialogTitleText)? true : false,  isImgUrl(data.content));
                }
                dialog = document.getElementById(dialogId),
                dialogContent = dialog.children[0].querySelectorAll("div.text-component")[0];

                if (dialogTitleText)
                    document.getElementById("title-" + dialogId).innerHTML = (dialogTitleText) ? dialogTitleText : null ;

                if (isDOMcontent(data.content)){
                    dialogContent.innerHTML = document.querySelector(data.content).innerHTML;
                    dialog.classList.replace("modal--is-loading", modalAnimateClass);
                } else {
                    if (isHTMLcontent(data.content)) {
                        dialogContent.innerHTML = data.content;
                        dialog.classList.replace("modal--is-loading", modalAnimateClass);
                    } else {
                        isImage = isImgUrl(data.content);
                        const options = {
                            method: "GET",
                            headers: {
                                "Access-Control-Allow-Origin": "*",
                            }
                        };
                    
                        const isResponseOk = (response) => {
                            if (!response.ok){
                                throw new Error(response.status);
                            }
                            if (isImage){
                                return response.url;
                            }
                            return response.text();
                        };
                        (async() => await fetch(data.content, options)
                            .then(response => isResponseOk(response))
                            .then(data => {
                                if (isImage) {
                                    dialogContent = dialog.children[0].querySelectorAll("img")[0];
                                    dialogContent.src = data;
                                } else {
                                    dialogContent.innerHTML = data;
                                }
                                dialog.classList.replace("modal--is-loading", modalAnimateClass);
                            })
                            .catch(err => {
                                console.error("ERROR ajax: ", err.message);
                                dialogContent.innerHTML = err.message;
                                dialog.classList.replace("modal--is-loading", modalAnimateClass);
                            }))();
                    }
                }
               
                var event = new CustomEvent("openModal");
                dialog.dispatchEvent(event);
                dialog.addEventListener("modalIsClose", function(event){
                    event.target.classList.replace(modalAnimateClass, "modal--is-loading");
                    if (modalDynamic)
                        document.getElementById(dialogId).remove();
                });
            },false);
        }
}());
