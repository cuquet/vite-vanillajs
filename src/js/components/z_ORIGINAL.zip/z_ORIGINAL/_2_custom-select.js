/* 
File#: _2_custom-select
Title: Custom Select
Descr: Custom select form element.
Usage: https://codyhouse.co/ds/components/info/custom-select

Dependencies:
    _1_popover
    _1_inputgroup
    _1_input-icon 
*/

(function() {
    var e = function(e) {
        this.element = e,
        this.select = this.element.getElementsByTagName("select")[0],
        this.optGroups = this.select.getElementsByTagName("optgroup"),
        this.options = this.select.getElementsByTagName("option"),
        this.selectedOption = function(e) {
            var t = "";
            t = "selectedIndex" in e.select ? e.options[e.select.selectedIndex].text : e.select.querySelector("option[selected]").text;
            return t;
        }(this),
        this.selectId = this.select.getAttribute("id"),
        this.trigger = !1,
        this.dropdown = !1,
        this.customOptions = !1,
        this.arrowIcon = this.element.getElementsByTagName("svg"),
        this.label = document.querySelector("[for=\"" + this.selectId + "\"]"),
        this.labelContent = "",
        this.label && (this.labelContent = ", " + this.label.textContent),
        this.optionIndex = 0,
        function(e) {
            e.element.insertAdjacentHTML("beforeend", function(e) {
                var t = e.element.getAttribute("data-trigger-class") ? " " + e.element.getAttribute("data-trigger-class") : "",
                    n = e.options[e.select.selectedIndex].innerHTML + e.labelContent,
                    o = "<button type=\"button\" class=\"js-select__button select__button" + t + "\" aria-label=\"" + n + "\" aria-expanded=\"false\" aria-controls=\"" + e.selectId + "-dropdown\"><span aria-hidden=\"true\" class=\"js-select__label select__label\">" + e.selectedOption + "</span>";
                if (0 < e.arrowIcon.length && e.arrowIcon[0].outerHTML) {
                    var s = e.arrowIcon[0].cloneNode(!0);
                    s.classList.remove("select__icon"),
                    o += s.outerHTML;
                }
                return o + "</button>";
            }(e) + function(e) {
                var t,
                    n = "<div class=\"js-select__dropdown select__dropdown\" aria-describedby=\"" + e.selectId + "-description\" id=\"" + e.selectId + "-dropdown\">";
                if (n += (t = e).label ? "<p class=\"sr-only\" id=\"" + t.selectId + "-description\">" + t.label.textContent + "</p>" : "", 0 < e.optGroups.length)
                    for (var o = 0; o < e.optGroups.length; o++) {
                        var s = e.optGroups[o].getElementsByTagName("option"),
                            i = "<li><span class=\"select__item select__item--optgroup\">" + e.optGroups[o].getAttribute("label") + "</span></li>";
                        n = n + "<ul class=\"select__list\" role=\"listbox\">" + i + l(e, s) + "</ul>";
                    }
                else
                    n = n + "<ul class=\"select__list\" role=\"listbox\">" + l(e, e.options) + "</ul>";
                return n;
            }(e)),
            e.dropdown = e.element.getElementsByClassName("js-select__dropdown")[0],
            e.trigger = e.element.getElementsByClassName("js-select__button")[0],
            e.customOptions = e.dropdown.getElementsByClassName("js-select__item"),
            e.select.classList.add("hide"),
            0 < e.arrowIcon.length && (e.arrowIcon[0].style.display = "none");
            e.minWidth = parseInt(getComputedStyle(e.dropdown).getPropertyValue("min-width")),
            i(e);
        }(this),
        function(t) {
            n = t,
            n.dropdown.addEventListener("click", function(e) {
                var t = e.target.closest(".js-select__item");
                t && function(e, t) {
                    if (t.hasAttribute("aria-selected") && "true" == t.getAttribute("aria-selected"))
                        e.trigger.setAttribute("aria-expanded", "false");
                    else {
                        var n = e.dropdown.querySelector("[aria-selected=\"true\"]");
                        n && n.setAttribute("aria-selected", "false"),
                        t.setAttribute("aria-selected", "true"),
                        e.trigger.getElementsByClassName("js-select__label")[0].textContent = t.textContent,
                        e.trigger.setAttribute("aria-expanded", "false"),
                        o = e,
                        s = t.getAttribute("data-index"),
                        o.select.selectedIndex = s,
                        o.select.dispatchEvent(new CustomEvent("change", {
                            bubbles: !0
                        })),
                        o.select.dispatchEvent(new CustomEvent("input", {
                            bubbles: !0
                        })),
                        r(e);
                    }
                    var o,
                        s;
                    e.trigger.focus();
                }(n, t);
            }),
            t.trigger.addEventListener("click", function() {
                s(t, !1);
            }),
            t.label && t.label.addEventListener("click", function() {
                a(t.trigger);
            });
            var n;
            t.dropdown.addEventListener("keydown", function(e) {
                e.keyCode && 38 == e.keyCode || e.key && "arrowup" == e.key.toLowerCase() ? o(t, "prev", e) : (e.keyCode && 40 == e.keyCode || e.key && "arrowdown" == e.key.toLowerCase()) && o(t, "next", e);
            }),
            t.element.addEventListener("select-updated", function() {
                !function(e) {
                    var t = e.dropdown.querySelector("[aria-selected=\"true\"]");
                    t && t.setAttribute("aria-selected", "false");
                    var n = e.dropdown.querySelector(".js-select__item[data-index=\"" + e.select.selectedIndex + "\"]");
                    n.setAttribute("aria-selected", "true"),
                    e.trigger.getElementsByClassName("js-select__label")[0].textContent = n.textContent,
                    e.trigger.setAttribute("aria-expanded", "false"),
                    r(e);
                }(t);
            });
        }(this);
    };
    function s(t, e) {
        var n,
            o;
        if (n = e || ("true" == t.trigger.getAttribute("aria-expanded") ? "false" : "true"), t.trigger.setAttribute("aria-expanded", n), "true" == n) {
            var s = (o = t).dropdown.querySelector("[aria-selected=\"true\"]") || o.dropdown.getElementsByClassName("js-select__item")[0];
            a(s),
            t.dropdown.addEventListener("transitionend", function e() {
                a(s),
                t.dropdown.removeEventListener("transitionend", e);
            }),
            i(t);
        }
    }
    function i(e) {
        e.dropdown.classList.remove("select__dropdown--right", "select__dropdown--up");
        var t = e.trigger.getBoundingClientRect();
        e.dropdown.classList.toggle("select__dropdown--right", document.documentElement.clientWidth - 5 < t.left + e.dropdown.offsetWidth);
        var n = window.innerHeight - t.bottom - 5 < t.top;
        e.dropdown.classList.toggle("select__dropdown--up", n);
        var o = n ? t.top - 20 : window.innerHeight - t.bottom - 20;
        e.minWidth < t.width ? e.dropdown.setAttribute("style", "max-height: " + o + "px; min-width: " + t.width + "px;") : e.dropdown.setAttribute("style", "max-height: " + o + "px;");
    }
    function o(e, t, n) {
        n.preventDefault();
        var o = Array.prototype.indexOf.call(e.customOptions, document.activeElement);
        (o = "next" == t ? o + 1 : o - 1) < 0 && (o = e.customOptions.length - 1),
        o >= e.customOptions.length && (o = 0),
        a(e.customOptions[o]);
    }
    function r(e) {
        e.trigger.setAttribute("aria-label", e.options[e.select.selectedIndex].innerHTML + e.labelContent);
    }
    function l(e, t) {
        for (var n = "", o = 0; o < t.length; o++) {
            var s = t[o].hasAttribute("selected") ? " aria-selected=\"true\"" : " aria-selected=\"false\"",
                i = t[o].hasAttribute("disabled") ? " disabled" : "";
            n = n + "<li><button type=\"button\" class=\"reset js-select__item select__item select__item--option\" role=\"option\" data-value=\"" + t[o].value + "\" " + s + i + " data-index=\"" + e.optionIndex + "\">" + t[o].text + "</button></li>",
            e.optionIndex = e.optionIndex + 1;
        }
        return n;
    }
    function a(e) {
        e.focus(),
        document.activeElement !== e && (e.setAttribute("tabindex", "-1"), e.focus());
    }
    var t,
        n = document.getElementsByClassName("js-select");
    if (0 < n.length) {
        for (var c = [], d = 0; d < n.length; d++)
            t = d,
            c.push(new e(n[t]));
        window.addEventListener("keyup", function(e) {
            (e.code && 27 == e.code || e.key && "escape" == e.key.toLowerCase()) && c.forEach(function(e) {
                var t;
                t = e,
                document.activeElement.closest(".js-select") && t.trigger.focus(),
                s(e, "false");
            });
        }),
        window.addEventListener("click", function(o) {
            c.forEach(function(e) {
                var t,
                    n;
                t = e,
                n = o.target,
                t.element.contains(n) || s(t, "false");
            });
        });
    }
}());