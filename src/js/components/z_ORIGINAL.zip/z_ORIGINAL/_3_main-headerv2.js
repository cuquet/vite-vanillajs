// File#: 3_main-headerv2
// Usage: https://codyhouse.co/ds/components/info/main-header-v2
(function() {
    var s = function(e) {
        var t;
        this.element = e,
        this.trigger = this.element.getElementsByClassName("header-v2__nav-link")[0],
        this.dropdown = this.element.getElementsByClassName("header-v2__nav-dropdown")[0],
        this.triggerFocus = !1,
        this.dropdownFocus = !1,
        this.hideInterval = !1,
        this.prevFocus = !1,
        n(t = this, t.trigger),
        n(t, t.dropdown),
        function(l) {
            for (var e = l.element.getElementsByClassName("header-v2__nav-list"), t = 0; t < e.length; t++) {
                e[t].children;
                new menuAim({
                    menu: e[t],
                    activate: function(e) {
                        var t = e.getElementsByClassName("header-v2__nav-dropdown")[0];
                        t && (e.querySelector("a.header-v2__nav-link").classList.add("header-v2__nav-link--hover"), r(l, t));
                    },
                    deactivate: function(e) {
                        var t = e.getElementsByClassName("header-v2__nav-dropdown")[0];
                        t && (e.querySelector("a.header-v2__nav-link").classList.remove("header-v2__nav-link--hover"), d(l, t));
                    },
                    exitMenu: function() {
                        return !0;
                    },
                    submenuSelector: ".header-v2__nav-item--has-children"
                });
            }
            l.element.addEventListener("keydown", function(e) {
                (e.keyCode && 9 == e.keyCode || e.key && "Tab" == e.key) && (l.prevFocus = document.activeElement);
            }),
            l.element.addEventListener("keyup", function(e) {
                if (e.keyCode && 9 == e.keyCode || e.key && "Tab" == e.key) {
                    var t = document.activeElement,
                        n = t.closest(".header-v2__nav-dropdown"),
                        i = t.nextElementSibling;
                    if (n && !n.classList.contains("header-v2__nav-list--is-visible") && r(l, n), i && !i.classList.contains("header-v2__nav-list--is-visible") && r(l, i), !l.prevFocus)
                        return;
                    var s = l.prevFocus.closest(".header-v2__nav-dropdown"),
                        o = l.prevFocus.nextElementSibling;
                    if (!s)
                        return;
                    if (n && n == s)
                        return void (o && d(l, o));
                    if (o && n && n == o)
                        return;
                    if (i && s && i == s)
                        return;
                    var a = n.parentNode.closest(".header-v2__nav-dropdown");
                    if (a && a == s)
                        return void (o && d(l, o));
                    s && s.classList.contains("header-v2__nav-list--is-visible") && d(l, s);
                }
            });
        }(this);
    };
    function n(t, e, n) {
        e.addEventListener("focus", function() {
            !0,
            function(e) {
                e.hideInterval && clearInterval(e.hideInterval);
                e.dropdown.classList.add("header-v2__nav-list--is-visible"),
                y(e.dropdown, !0);
            }(t);
        }),
        e.addEventListener("focusout", function(e) {
            !1,
            function(n, e) {
                n.hideInterval && clearInterval(this.hideInterval);
                n.hideInterval = setTimeout(function() {
                    var e = document.activeElement.closest(".header-v2__nav-item--main"),
                        t = e && e == n.element;
                    n.triggerFocus || n.dropdownFocus || t || (n.dropdown.classList.remove("header-v2__nav-list--is-visible"), y(n.dropdown, !1), function(e) {
                        var t = e.dropdown.getElementsByClassName("header-v2__nav-list--is-visible");
                        if (0 == t.length)
                            return;
                        for (; t[0];)
                            d(e, t[0]);
                        var n = e.dropdown.getElementsByClassName("header-v2__nav-link--hover");
                        for (; n[0];)
                            n[0].classList.remove("header-v2__nav-link--hover");
                    }(n), n.prevFocus = !1);
                }, 100);
            }(t);
        });
    }
    function r(e, t, n) {
        if (null == n) {
            t.classList.remove("header-v2__nav-dropdown--nested-left");
            var i = t.getBoundingClientRect();
            window.innerWidth - i.right < 5 && i.left + window.scrollX > 2 * i.width && t.classList.add("header-v2__nav-dropdown--nested-left");
        }
        t.classList.add("header-v2__nav-list--is-visible");
    }
    function d(e, t) {
        t.classList.contains("header-v2__nav-list--is-visible") && (t.classList.remove("header-v2__nav-list--is-visible"), t.addEventListener("transition", function e() {
            t.removeEventListener("transition", e),
            t.classList.remove("header-v2__nav-dropdown--nested-left");
        }));
    }
    var i = document.getElementsByClassName("js-header-v2");
    if (0 < i.length) {
        var t = i[0].getElementsByClassName("js-anim-menu-btn")[0],
            o = function() {
                for (var e = i[0].getElementsByClassName("header-v2__nav")[0].querySelectorAll("[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [tabindex]:not([tabindex=\"-1\"]), [contenteditable], audio[controls], video[controls], summary"), t = !1, n = 0; n < e.length; n++)
                    if (e[n].offsetWidth || e[n].offsetHeight || e[n].getClientRects().length) {
                        t = e[n];
                        break;
                    }
                return t;
            }(),
            a = !1;
        t.addEventListener("anim-menu-btn-clicked", function(e) {
            document.getElementsByClassName("header-v2__nav")[0].classList.toggle("header-v2__nav--is-visible", e.detail),
            i[0].classList.toggle("header-v2--expanded", e.detail),
            t.setAttribute("aria-expanded", e.detail),
            e.detail ? o.focus() : a && (a.focus(), a = !1);
        });
        var l = i[0].getElementsByClassName("header-v2__nav-list--main");
        if (0 < l.length)
            for (var e = 0; e < l.length; e++)
                !function(e) {
                    new menuAim({
                        menu: l[e],
                        activate: function(e) {
                            var t = e.getElementsByClassName("header-v2__nav-dropdown");
                            0 != t.length && (t[0].classList.add("header-v2__nav-list--is-visible"), y(t[0], !0));
                        },
                        deactivate: function(e) {
                            var t = e.getElementsByClassName("header-v2__nav-dropdown");
                            0 != t.length && (t[0].classList.remove("header-v2__nav-list--is-visible"), y(t[0], !1));
                        },
                        exitMenu: function() {
                            return !0;
                        },
                        submenuSelector: ".header-v2__nav-item--has-children",
                        submenuDirection: "below"
                    });
                    for (var t, n = l[e].getElementsByClassName("header-v2__nav-item--main"), i = 0; i < n.length; i++)
                        n[t = i].classList.contains("header-v2__nav-item--has-children") && new s(n[t]);
                }(e);
        var c = i[0].getAttribute("data-animation");
        if (c && "on" == c) {
            var u = !1,
                v = i[0].getAttribute("data-animation-offset") ? parseInt(i[0].getAttribute("data-animation-offset")) : 400,
                h = i[0].offsetHeight,
                m = i[0].getElementsByClassName("header-v2__wrapper")[0];
            function f() {
                var e = window.scrollY || document.documentElement.scrollTop;
                m.classList.toggle("header-v2__wrapper--is-fixed", h <= e),
                m.classList.toggle("header-v2__wrapper--slides-down", v <= e),
                u = !1;
            }
            window.addEventListener("scroll", function(e) {
                u || (u = !0, window.requestAnimationFrame ? window.requestAnimationFrame(f) : setTimeout(function() {
                    f();
                }, 250));
            });
        }
        window.addEventListener("keyup", function(e) {
            (e.keyCode && 27 == e.keyCode || e.key && "escape" == e.key.toLowerCase()) && "true" == t.getAttribute("aria-expanded") && b(t) && (a = t).click(),
            (e.keyCode && 9 == e.keyCode || e.key && "tab" == e.key.toLowerCase()) && "true" == t.getAttribute("aria-expanded") && b(t) && !document.activeElement.closest(".js-header-v2") && t.click();
        });
        var g = !1;
        function p() {
            !b(t) && i[0].classList.contains("header-v2--expanded") && t.click();
        }
        window.addEventListener("resize", function() {
            clearTimeout(g),
            g = setTimeout(p, 500);
        });
    }
    function y(t, e) {
        if (e) {
            var n = t.getBoundingClientRect();
            if (window.innerWidth - n.right < 5 && n.left + window.scrollX > 2 * n.width) {
                var i = parseFloat(window.getComputedStyle(t).getPropertyValue("left"));
                t.style.left = i + window.innerWidth - n.right - 5 + "px";
            }
        } else
            t.addEventListener("transitionend", function e() {
                t.removeAttribute("style"),
                t.removeEventListener("transitionend", e);
            });
    }
    function b(e) {
        return e.offsetWidth || e.offsetHeight || e.getClientRects().length;
    }
}());