/* eslint-disable no-undef */
import { addClass, toggleClass } from '../utils';

(function() {
    class StickyBar {
        constructor(e) {
            this.element = e,
                this.contentTarget = document.getElementsByClassName('js-sticky-sharebar-target'),
                this.contentTargetOut = document.getElementsByClassName('js-sticky-sharebar-target-out'),
                this.showClass = 'sticky-sharebar--on-target',
                this.threshold = '50%',
                function (e) {
                    if (e.contentTarget.length < 1) { return e.showSharebar = !0, addClass(e.element, e.showClass); }
                    a ? (e.showSharebar = !1, n = e, new IntersectionObserver(function (e) {
                        n.showSharebar = e[0].isIntersecting,
                            s(n);
                    }, {
                        rootMargin: '0px 0px -' + n.threshold + ' 0px'
                    }).observe(n.contentTarget[0])) : addClass(e.element, e.showClass);
                    var n;
                } (this),
                function (n) {
                    if (n.hideSharebar = !1, n.contentTargetOut.length < 1) return;
                    new IntersectionObserver(function (e) {
                        n.hideSharebar = e[0].isIntersecting,
                    s(n);
                }).observe(n.contentTargetOut[0]);
            } (this);
        }
    }
    function s(e) {
        toggleClass(e.element, e.showClass, e.showSharebar && !e.hideSharebar);
    }
    const t = document.getElementsByClassName('js-sticky-sharebar');
    const a = 'IntersectionObserver' in window && 'IntersectionObserverEntry' in window && 'intersectionRatio' in window.IntersectionObserverEntry.prototype;
    if (t.length > 0) {
        for (let n = 0; n < t.length; n += 1) {
            new StickyBar(t[n]); 
        }
    }
}());
