//_1_row-table
(function() {
    var e = function(e) {
        var t;
        this.element = e,
        this.headerRows = this.element.getElementsByTagName("thead")[0].getElementsByTagName("th"),
        this.tableRows = this.element.getElementsByTagName("tbody")[0].getElementsByTagName("tr"),
        this.collapsedLayoutClass = "row-table--collapsed",
        this.mainRowCellClass = "row-table__th-inner",
        function(e) {
            for (var t = 0; t < e.tableRows.length; t++) {
                for (var l = "", s = e.tableRows[t].getElementsByClassName("row-table__cell"), a = 0; a < s.length; a++)
                    if (0 == a) {
                        s[a].classList.add("js-" + e.mainRowCellClass);
                        var n = s[a].getElementsByClassName("row-table__th-inner");
                        0 < n.length && (n[0].innerHTML = n[0].innerHTML + "<i class=\"row-table__th-icon\" aria-hidden=\"true\"></i>");
                    } else
                        l = l + "<li class=\"row-table__item\"><span class=\"row-table__label\">" + e.headerRows[a].innerHTML + ":</span><span>" + s[a].innerHTML + "</span></li>";
                l = "<ul class=\"row-table__list\" aria-hidden=\"true\">" + l + "</ul>",
                s[0].innerHTML = "<input type=\"text\" class=\"row-table__input\" aria-hidden=\"true\">" + s[0].innerHTML + l;
            }
        }(t = this),
        t.element.addEventListener("click", function(e) {
            l(t, e);
        }),
        t.element.addEventListener("keydown", function(e) {
            (e.keyCode && 13 == e.keyCode || e.key && "enter" == e.key.toLowerCase()) && l(t, e);
        });
    };
    function l(e, t) {
        if (t.target.closest(".js-" + e.mainRowCellClass) && !t.target.closest(".row-table__list")) {
            var l = t.target.closest(".js-" + e.mainRowCellClass);
            l.classList.toggle("row-table__cell--show-list", !l.classList.contains("row-table__cell--show-list"));
        }
    }
    var t = document.getElementsByClassName("js-row-table");
    if (0 < t.length)
        for (var s = 0; s < t.length; s++)
            new e(t[s]);
}());
