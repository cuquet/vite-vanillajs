//_2_menu-bar.js
(function() {
    var e = function(e) {
        this.element = e,
        this.items = function(e, t) {
            for (var n = e.children, i = [], s = 0; s < n.length; s++)
                n[s].classList.contains(t) && i.push(n[s]);
            return i;
        }(this.element, "menu-bar__item"),
        this.mobHideItems = this.element.getElementsByClassName("menu-bar__item--hide"),
        this.moreItemsTrigger = this.element.getElementsByClassName("js-menu-bar__trigger"),
        function(t) {
            (function(e) {
                for (var t = !1, n = 0; n < e.items.length; n++)
                    0 == n || t ? e.items[n].setAttribute("tabindex", "0") : e.items[n].setAttribute("tabindex", "-1"),
                    t = 0 == n && 0 < e.moreItemsTrigger.length;
            })(t),
            function(e) {
                if (0 == e.mobHideItems.length)
                    return 0 < e.moreItemsTrigger.length && e.element.removeChild(e.moreItemsTrigger[0]);
                if (0 != e.moreItemsTrigger.length) {
                    var t = "";
                    e.menuControlId = "submenu-bar-" + Date.now();
                    for (var n = 0; n < e.mobHideItems.length; n++) {
                        var i = e.mobHideItems[n].cloneNode(!0),
                            s = i.getElementsByTagName("svg")[0],
                            r = i.getElementsByClassName("menu-bar__label")[0];
                        s.setAttribute("class", "icon menu__icon"),
                        t = t + "<li role=\"menuitem\"><span class=\"menu__content js-menu__content\">" + s.outerHTML + "<span>" + r.innerHTML + "</span></span></li>";
                    }
                    e.moreItemsTrigger[0].setAttribute("role", "button"),
                    e.moreItemsTrigger[0].setAttribute("aria-expanded", "false"),
                    e.moreItemsTrigger[0].setAttribute("aria-controls", e.menuControlId),
                    e.moreItemsTrigger[0].setAttribute("aria-haspopup", "true");
                    var o = document.createElement("menu"),
                        a = e.element.getAttribute("data-menu-class");
                    o.setAttribute("id", e.menuControlId),
                    o.setAttribute("class", "menu js-menu " + a),
                    o.innerHTML = t,
                    document.body.appendChild(o),
                    e.subMenu = o,
                    e.subItems = o.getElementsByTagName("li"),
                    // eslint-disable-next-line no-undef
                    e.menuInstance = new Menu(e.subMenu);
                }
            }(t),
            n(t),
            t.element.classList.add("menu-bar--loaded"),
            t.element.addEventListener("update-menu-bar", function() {
                n(t),
                t.menuInstance && t.menuInstance.toggleMenu(!1, !1);
            }),
            0 < t.moreItemsTrigger.length && (t.moreItemsTrigger[0].addEventListener("keydown", function(e) {
                if (e.keyCode && 13 == e.keyCode || e.key && "enter" == e.key.toLowerCase()) {
                    if (!t.menuInstance)
                        return;
                    t.menuInstance.selectedTrigger = t.moreItemsTrigger[0],
                    t.menuInstance.toggleMenu(!t.subMenu.classList.contains("menu--is-visible"), !0);
                }
            }), t.subMenu.addEventListener("keydown", function(e) {
                (e.keyCode && 27 == e.keyCode || e.key && "escape" == e.key.toLowerCase()) && t.menuInstance && t.menuInstance.toggleMenu(!1, !0);
            }));
            t.element.addEventListener("keydown", function(e) {
                e.keyCode && 39 == e.keyCode || e.key && "arrowright" == e.key.toLowerCase() ? a(t.items, e, "next") : (e.keyCode && 37 == e.keyCode || e.key && "arrowleft" == e.key.toLowerCase()) && a(t.items, e, "prev");
            });
        }(this);
    };
    function n(e) {
        // eslint-disable-next-line no-useless-escape
        var t = getComputedStyle(e.element, ":before").getPropertyValue("content").replace(/\'|"/g, "");
        e.element.classList.toggle("menu-bar--collapsed", "collapsed" == t);
    }
    function a(e, t, n, i) {
        t.preventDefault();
        var s,
            r = void 0 !== i ? i : Array.prototype.indexOf.call(e, t.target),
            o = "next" == n ? r + 1 : r - 1;
        o < 0 && (o = e.length - 1),
        o > e.length - 1 && (o = 0),
        null === e[o].offsetParent ? a(e, t, n, o) : ((s = e[o]).focus(), document.activeElement !== s && (s.setAttribute("tabindex", "-1"), s.focus()));
    }
    var t,
        i = document.getElementsByClassName("js-menu-bar");
    if (0 < i.length) {
        for (var s = 0, r = [], o = 0; o < i.length; o++) {
            var u = getComputedStyle(i[o], ":before").getPropertyValue("content");
            u && "" != u && "none" != u && (t = o, r.push(new e(i[t])), s += 1);
        }
        if (0 < s) {
            var l = !1,
                m = new CustomEvent("update-menu-bar");
            window.addEventListener("resize", function() {
                clearTimeout(l),
                l = setTimeout(c, 150);
            }),
            window.addEventListener("click", function(i) {
                r.forEach(function(e) {
                    var t,
                        n;
                    t = e,
                    n = i.target,
                    !t.menuInstance || t.moreItemsTrigger[0].contains(n) || t.subMenu.contains(n) || t.menuInstance.toggleMenu(!1, !1);
                });
            });
        }
    }
    function c() {
        for (var e = 0; e < i.length; e++)
            i[e].dispatchEvent(m);
    }
}());