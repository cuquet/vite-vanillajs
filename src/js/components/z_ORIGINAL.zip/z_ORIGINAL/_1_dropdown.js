//_1_dropdown
//https://codyhouse.co/ds/components/info/dropdown

/* (function() {
    Window.menuAim = function(e) {
        !function(e) {
            var h = null,
                f = [],
                w = null,
                n = null,
                y = p({
                    menu: "",
                    rows: !1,
                    submenuSelector: "*",
                    submenuDirection: "right",
                    tolerance: 75,
                    enter: function() {},
                    exit: function() {},
                    activate: function() {},
                    deactivate: function() {},
                    exitMenu: function() {}
                }, e),
                _ = y.menu,
                t = function(e) {
                    window.requestAnimationFrame ? window.requestAnimationFrame(function() {
                        o(e);
                    }) : o(e);
                },
                o = function(e) {
                    f.push({
                        x: e.pageX,
                        y: e.pageY
                    }),
                    3 < f.length && f.shift();
                },
                i = function() {
                    n && clearTimeout(n),
                    y.exitMenu(this) && (h && y.deactivate(h), h = null);
                },
                r = function() {
                    n && clearTimeout(n),
                    y.enter(this),
                    u(this);
                },
                s = function() {
                    y.exit(this);
                },
                d = function() {
                    l(this);
                },
                l = function(e) {
                    e != h && (h && y.deactivate(h), y.activate(e), h = e);
                },
                u = function(e) {
                    var t = a();
                    t ? n = setTimeout(function() {
                        u(e);
                    }, t) : l(e);
                },
                a = function() {
                    if (!h || !function(e, t) {
                        if (t.nodeType)
                            return e === t;
                        for (var n = "string" == typeof t ? document.querySelectorAll(t) : t, o = n.length; o--;)
                            if (n[o] === e)
                                return !0;
                        return !1;
                    }(h, y.submenuSelector))
                        return 0;
                    var e,
                        t = {
                            top: (e = _.getBoundingClientRect()).top + window.pageYOffset,
                            left: e.left + window.pageXOffset
                        },
                        n = {
                            x: t.left,
                            y: t.top - y.tolerance
                        },
                        o = {
                            x: t.left + _.offsetWidth,
                            y: n.y
                        },
                        i = {
                            x: t.left,
                            y: t.top + _.offsetHeight + y.tolerance
                        },
                        r = {
                            x: t.left + _.offsetWidth,
                            y: i.y
                        },
                        s = f[f.length - 1],
                        d = f[0];
                    if (!s)
                        return 0;
                    if (d || (d = s), d.x < t.left || d.x > r.x || d.y < t.top || d.y > r.y)
                        return 0;
                    if (w && s.x == w.x && s.y == w.y)
                        return 0;
                    function l(e, t) {
                        return (t.y - e.y) / (t.x - e.x);
                    }
                    var u = o,
                        a = r;
                    "left" == y.submenuDirection ? (u = i, a = n) : "below" == y.submenuDirection ? (u = r, a = i) : "above" == y.submenuDirection && (u = n, a = o);
                    var c = l(s, u),
                        v = l(s, a),
                        m = l(d, u),
                        p = l(d, a);
                    return c < m && p < v ? (w = s, 300) : (w = null, 0);
                };
            _.addEventListener("mouseleave", i);
            var c,
                v = y.rows ? y.rows : _.children;
            if (0 < v.length)
                for (var m = 0; m < v.length; m++)
                    v[c = m].addEventListener("mouseenter", r),
                    v[c].addEventListener("mouseleave", s),
                    v[c].addEventListener("click", d);
            document.addEventListener("mousemove", t),
            _.addEventListener("reset", function(e) {
                var t;
                t = e.detail,
                n && clearTimeout(n),
                h && t && y.deactivate(h),
                h = null;
            }),
            _.addEventListener("destroy", function() {
                if (_.removeEventListener("mouseleave", i), document.removeEventListener("mousemove", t), 0 < v.length)
                    for (var e = 0; e < v.length; e++)
                        v[e].removeEventListener("mouseenter", r),
                        v[e].removeEventListener("mouseleave", s),
                        v[e].removeEventListener("click", d);
            });
        }(e);
    };
    var p = function() {
        var n = {},
            o = !1,
            e = 0,
            t = arguments.length;
        "[object Boolean]" === Object.prototype.toString.call(arguments[0]) && (o = arguments[0], e++);
        for (var i = function(e) {
            for (var t in e)
                // eslint-disable-next-line no-undef
                Object.prototype.hasOwnProperty.call(e, t) && (o && "[object Object]" === Object.prototype.toString.call(e[t]) ? n[t] = Util.extend(!0, n[t], e[t]) : n[t] = e[t]);
        }; e < t; e++) {
            i(arguments[e]);
        }
        return n;
    };
}(),*/

(function() {
    var DropDown = function(e) {
        this.element = e,
        this.trigger = this.element.getElementsByClassName("js-dropdown__trigger")[0],
        this.dropdown = this.element.getElementsByClassName("js-dropdown__menu")[0],
        this.triggerFocus = !1,
        this.dropdownFocus = !1,
        this.hideInterval = !1,
        this.dropdownSubElements = this.element.getElementsByClassName("js-dropdown__sub-wrapper"),
        this.prevFocus = !1,
        this.addDropdownEvents();
    };
    DropDown.prototype.addDropdownEvents = function() {
        var t = this;
        this.placeElement(),
        this.element.addEventListener("placeDropdown", function() {
            t.placeElement();
        }),
        this.initElementEvents(this.trigger, this.triggerFocus),
        this.initElementEvents(this.dropdown, this.dropdownFocus),
        this.initSublevels();
    },
    DropDown.prototype.placeElement = function() {
        this.dropdown.removeAttribute("style");
        var e = this.trigger.getBoundingClientRect(),
            t = window.innerWidth < e.left + parseInt(getComputedStyle(this.dropdown).getPropertyValue("width")) ? "right: 0px; left: auto;" : "left: 0px; right: auto;";
        this.dropdown.setAttribute("style", t);
    },
    DropDown.prototype.initElementEvents = function(e) {
        var n = this;
        e.addEventListener("mouseenter", function() {
            !0,
            n.showDropdown();
        }),
        e.addEventListener("focus", function() {
            n.showDropdown();
        }),
        e.addEventListener("mouseleave", function() {
            !1,
            n.hideDropdown();
        }),
        e.addEventListener("focusout", function() {
            n.hideDropdown();
        });
    },
    DropDown.prototype.showDropdown = function() {
        this.hideInterval && clearInterval(this.hideInterval),
        this.dropdown.removeAttribute("style"),
        this.placeElement(),
        this.showLevel(this.dropdown, !0);
    },
    DropDown.prototype.hideDropdown = function() {
        var n = this;
        this.hideInterval && clearInterval(this.hideInterval),
        this.hideInterval = setTimeout(function() {
            var e = document.activeElement.closest(".js-dropdown"),
                t = e && e == n.element;
            n.triggerFocus || n.dropdownFocus || t || (n.hideLevel(n.dropdown, !0), n.hideSubLevels(), n.prevFocus = !1);
        }, 300);
    },
    DropDown.prototype.initSublevels = function() {
        var menuAim = Window.menuAim;
        for (var d = this, e = this.element.getElementsByClassName("js-dropdown__menu"), t = 0; t < e.length; t++) {
            e[t].children;
            new menuAim({
                menu: e[t],
                activate: function(e) {
                    var t = e.getElementsByClassName("js-dropdown__menu")[0];
                    t && (e.querySelector("a").classList.add("dropdown__item--hover"), d.showLevel(t));
                },
                deactivate: function(e) {
                    var t = e.getElementsByClassName("dropdown__menu")[0];
                    t && (e.querySelector("a").classList.remove("dropdown__item--hover"), d.hideLevel(t));
                },
                submenuSelector: ".js-dropdown__sub-wrapper"
            });
        }
        this.element.addEventListener("keydown", function(e) {
            (e.keyCode && 9 == e.keyCode || e.key && "Tab" == e.key) && (d.prevFocus = document.activeElement);
        }),
        this.element.addEventListener("keyup", function(e) {
            if (e.keyCode && 9 == e.keyCode || e.key && "Tab" == e.key) {
                var t = document.activeElement,
                    n = t.closest(".js-dropdown__menu"),
                    o = t.nextElementSibling;
                if (n && !n.classList.contains("dropdown__menu--is-visible") && d.showLevel(n), o && !o.classList.contains("dropdown__menu--is-visible") && d.showLevel(o), !d.prevFocus)
                    return;
                var i = d.prevFocus.closest(".js-dropdown__menu"),
                    r = d.prevFocus.nextElementSibling;
                if (!i)
                    return;
                if (n && n == i)
                    return void (r && d.hideLevel(r));
                if (r && n && n == r)
                    return;
                if (o && i && o == i)
                    return;
                var s = n.parentNode.closest(".js-dropdown__menu");
                if (s && s == i)
                    return void (r && d.hideLevel(r));
                i && i.classList.contains("dropdown__menu--is-visible") && d.hideLevel(i);
            }
        });
    },
    DropDown.prototype.hideSubLevels = function() {
        var e = this.dropdown.getElementsByClassName("dropdown__menu--is-visible");
        if (0 != e.length) {
            for (; e[0];)
                this.hideLevel(e[0]);
            for (var t = this.dropdown.getElementsByClassName("dropdown__item--hover"); t[0];)
                t[0].classList.remove("dropdown__item--hover");
        }
    },
    DropDown.prototype.showLevel = function(e, t) {
        if (null == t) {
            e.classList.remove("dropdown__menu--left");
            var n = e.getBoundingClientRect();
            window.innerWidth - n.right < 5 && n.left + window.scrollX > 2 * n.width && e.classList.add("dropdown__menu--left");
        }
        e.classList.add("dropdown__menu--is-visible"),
        e.classList.remove("dropdown__menu--hide");
    },
    DropDown.prototype.hideLevel = function(n, o) {
        n.classList.contains("dropdown__menu--is-visible") && (n.classList.remove("dropdown__menu--is-visible"), n.classList.add("dropdown__menu--hide"), n.addEventListener("transitionend", function e(t) {
            "opacity" == t.propertyName && (n.removeEventListener("transitionend", e), n.classList.contains("dropdown__menu--is-hidden") && n.classList.remove("dropdown__menu--is-hidden", "dropdown__menu--left"), o && !n.classList.contains("dropdown__menu--is-visible") && n.setAttribute("style", "width: 0px; overflow: hidden;"));
        }));
    },
    window.Dropdown = DropDown;
    var t = document.getElementsByClassName("js-dropdown");
    if (0 < t.length)
        for (let n = 0; n < t.length; n += 1)
            new DropDown(t[n]);
}());
