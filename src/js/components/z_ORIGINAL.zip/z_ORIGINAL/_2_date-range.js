/* eslint-disable no-undef */
(!function() {
    var e = function(e) {
        var t;
        this.options = N(DatePicker.defaults, e),
        this.element = this.options.element,
        this.inputStart = this.element.getElementsByClassName("js-date-range__text--start")[0],
        this.inputEnd = this.element.getElementsByClassName("js-date-range__text--end")[0],
        this.trigger = this.element.getElementsByClassName("js-date-range__trigger")[0],
        this.triggerLabel = this.trigger.getAttribute("aria-label"),
        this.datePicker = this.element.getElementsByClassName("js-date-picker")[0],
        this.body = this.datePicker.getElementsByClassName("js-date-picker__dates")[0],
        this.navigation = this.datePicker.getElementsByClassName("js-date-picker__month-nav")[0],
        this.heading = this.datePicker.getElementsByClassName("js-date-picker__month-label")[0],
        this.pickerVisible = !1,
        this.dateIndexes = [(t = this.options.dateFormat.toLowerCase().replace(/-/g, "")).indexOf("d"), t.indexOf("m"), t.indexOf("y")],
        this.dateSelected = [],
        this.selectedDay = [],
        this.selectedMonth = [],
        this.selectedYear = [],
        this.dateToSelect = 0,
        this.firstFocusable = !1,
        this.lastFocusable = !1,
        this.dateValueStartEl = this.element.getElementsByClassName("js-date-range__value--start"),
        this.dateValueEndEl = this.element.getElementsByClassName("js-date-range__value--end"),
        0 < this.dateValueStartEl.length && (this.dateValueStartElLabel = this.dateValueStartEl[0].textContent),
        0 < this.dateValueEndEl.length && (this.dateValueEndElLabel = this.dateValueEndEl[0].textContent),
        this.triggerLabelWrapper = this.trigger.getElementsByClassName("js-date-range__trigger-label"),
        this.selectedStartClass = "date-picker__date--selected js-date-picker__date--range-start",
        this.selectedEndClass = "date-picker__date--selected date-picker__date--range-end js-date-picker__date--range-end",
        this.inBetweenClass = "date-picker__date--range",
        this.mouseMoving = !1,
        this.predefOptions = this.element.previousElementSibling,
        function(e) {
            n(e.inputStart),
            n(e.inputEnd);
            var t = document.createElement("div");
            t.setAttribute("aria-live", "polite"),
            t.classList.add("sr-only", "js-date-range__sr-live"),
            e.element.appendChild(t),
            e.srLiveReagionM = e.element.getElementsByClassName("js-date-range__sr-live")[0];
        }(this),
        a(this),
        f(this, !0),
        function(d) {
            d.trigger && d.trigger.addEventListener("click", function(e) {
                var t,
                    n;
                e.preventDefault(),
                d.pickerVisible = !1,
                (t = d).pickerVisible ? c(t) : (a(t), l(t, n)),
                d.trigger.setAttribute("aria-expanded", "true");
            });
            d.navigation.addEventListener("click", function(e) {
                e.preventDefault();
                var t = e.target.closest(".js-date-picker__month-nav-btn");
                t && (t.classList.contains("js-date-picker__month-nav-btn--prev") ? o(d, !0) : i(d, !0));
            }),
            window.addEventListener("keydown", function(e) {
                if (e.keyCode && 27 == e.keyCode || e.key && "escape" == e.key.toLowerCase()) {
                    if (!d.pickerVisible)
                        return;
                    document.activeElement.closest(".js-date-picker") && d.trigger.focus(),
                    c(d);
                }
            }),
            window.addEventListener("click", function(e) {
                e.target.closest(".js-date-picker") || e.target.closest(".js-date-range__trigger") || !d.pickerVisible || c(d);
            }),
            d.body.addEventListener("keydown", function(e) {
                var t = d.currentDay;
                e.keyCode && 40 == e.keyCode || e.key && "arrowdown" == e.key.toLowerCase() ? v(t += 7, d) : e.keyCode && 39 == e.keyCode || e.key && "arrowright" == e.key.toLowerCase() ? v(t += 1, d) : e.keyCode && 37 == e.keyCode || e.key && "arrowleft" == e.key.toLowerCase() ? v(t -= 1, d) : e.keyCode && 38 == e.keyCode || e.key && "arrowup" == e.key.toLowerCase() ? v(t -= 7, d) : e.keyCode && 35 == e.keyCode || e.key && "end" == e.key.toLowerCase() ? (e.preventDefault(), v(t = t + 6 - y(d.currentYear, d.currentMonth, t), d)) : e.keyCode && 36 == e.keyCode || e.key && "home" == e.key.toLowerCase() ? (e.preventDefault(), v(t -= y(d.currentYear, d.currentMonth, t), d)) : e.keyCode && 34 == e.keyCode || e.key && "pagedown" == e.key.toLowerCase() ? (e.preventDefault(), i(d), D(d)) : (e.keyCode && 33 == e.keyCode || e.key && "pageup" == e.key.toLowerCase()) && (e.preventDefault(), o(d), D(d));
            }),
            d.datePicker.addEventListener("keydown", function(e) {
                (e.code && 9 == e.code || e.key && "Tab" == e.key) && function(e, t) {
                    t.firstFocusable == document.activeElement && e.shiftKey && (e.preventDefault(), t.lastFocusable.focus());
                    t.lastFocusable != document.activeElement || e.shiftKey || (e.preventDefault(), t.firstFocusable.focus());
                }(e, d);
            }),
            d.body.addEventListener("click", function(e) {
                e.preventDefault();
                var t,
                    n,
                    r,
                    a,
                    s,
                    i,
                    o = e.target.closest("button");
                o && (1 == d.dateToSelect && (a = o, s = [(r = d).currentYear, r.currentMonth, parseInt(a.textContent)], i = [r.selectedYear[0], r.selectedMonth[0], r.selectedDay[0]], S(s, i)) && (d.dateToSelect = 0), d.dateSelected[d.dateToSelect] = !0, d.selectedDay[d.dateToSelect] = parseInt(o.innerText), d.selectedMonth[d.dateToSelect] = d.currentMonth, d.selectedYear[d.dateToSelect] = d.currentYear, 0 == d.dateToSelect ? ((n = d).inputStart.value = b(n, 0), d.dateToSelect = 1, function(e, t) {
                    e.dateSelected[1] = !1,
                    e.selectedDay[1] = !1,
                    e.selectedMonth[1] = !1,
                    e.selectedYear[1] = !1,
                    e.inputEnd.value = "";
                    var n = e.element.getElementsByClassName("js-date-picker__date--range-start");
                    0 < n.length && A(n[0], e.selectedStartClass + " date-picker__date--range-start");
                    var r = e.element.getElementsByClassName("js-date-picker__date--range-end");
                    0 < r.length && A(r[0], e.selectedEndClass);
                    M(e),
                    function e(t, n) {
                        var r = n.split(" ");
                        t.classList.add(r[0]);
                        1 < r.length && e(t, r.slice(1).join(" "));
                    }(t, e.selectedStartClass);
                }(d, o)) : ((t = d).inputEnd.value = b(t, 1), d.dateToSelect = 0, c(d)), C(d), _(d), E(d));
            }),
            d.body.addEventListener("mousemove", function(e) {
                var t = e.target.closest(".js-date-picker__date");
                t && d.dateSelected[0] && !d.dateSelected[1] && L(d, t);
            }),
            d.body.addEventListener("mouseleave", function() {
                d.dateSelected[1] || (M(d), j(d));
            }),
            d.inputStart.addEventListener("focusout", function() {
                r(d, d.inputStart);
            }),
            d.inputEnd.addEventListener("focusout", function() {
                r(d, d.inputEnd);
            });
        }(this),
        Y(this),
        function(t) {
            if (!t.predefOptions || !t.predefOptions.classList.contains("js-date-range-select"))
                return;
            var n = t.predefOptions.querySelector("select");
            if (!n)
                return;
            "custom" == n.options[n.selectedIndex].value && t.element.classList.remove("hide");
            n.addEventListener("change", function() {
                "custom" == n.options[n.selectedIndex].value ? (t.element.classList.remove("hide"), Y(t), t.trigger.focus()) : t.element.classList.add("hide");
            });
        }(this);
    };
    function n(e) {
        e.setAttribute("tabindex", "-1");
        var t = e.closest(".js-date-range__input");
        t && (t.classList.add("sr-only"), t.style.display = "block");
    }
    function r(e, t) {
        var n = d(e, t.value);
        n ? isNaN(new Date(n).getTime()) ? t.value = "" : a(e) : t.value = "";
    }
    function a(e) {
        t(e, 0),
        t(e, 1),
        C(e),
        _(e),
        E(e);
    }
    function t(e, t) {
        var n = !1,
            r = 0 == t ? e.inputStart.value : e.inputEnd.value;
        if (e.dateSelected[t] = !1, "" != r) {
            var a = d(e, r);
            e.dateSelected[t] = !0,
            n = a;
        }
        0 == t && (e.currentDay = u(n), e.currentMonth = g(n), e.currentYear = p(n)),
        e.selectedDay[t] = !!e.dateSelected[t] && u(n),
        e.selectedMonth[t] = !!e.dateSelected[t] && g(n),
        e.selectedYear[t] = !!e.dateSelected[t] && p(n);
    }
    function u(e) {
        return e ? (t = parseInt(e.split("-")[2]), isNaN(t) ? u(!1) : t) : (new Date).getDate();
        var t;
    }
    function g(e) {
        return e ? (t = parseInt(e.split("-")[1]) - 1, isNaN(t) ? g(!1) : t) : (new Date).getMonth();
        var t;
    }
    function p(e) {
        return e ? (t = parseInt(e.split("-")[0]), isNaN(t) ? p(!1) : t) : (new Date).getFullYear();
        var t;
    }
    function i(e, t) {
        e.currentYear = 11 === e.currentMonth ? e.currentYear + 1 : e.currentYear,
        e.currentMonth = (e.currentMonth + 1) % 12,
        e.currentDay = s(e),
        l(e, t),
        e.srLiveReagionM.textContent = e.options.months[e.currentMonth] + " " + e.currentYear;
    }
    function o(e, t) {
        e.currentYear = 0 === e.currentMonth ? e.currentYear - 1 : e.currentYear,
        e.currentMonth = 0 === e.currentMonth ? 11 : e.currentMonth - 1,
        e.currentDay = s(e),
        l(e, t),
        e.srLiveReagionM.textContent = e.options.months[e.currentMonth] + " " + e.currentYear;
    }
    function s(e) {
        return e.currentDay > h(e.currentYear, e.currentMonth) ? 1 : e.currentDay;
    }
    function h(e, t) {
        return 32 - new Date(e, t, 32).getDate();
    }
    function l(e, t) {
        var n = y(e.currentYear, e.currentMonth, "01");
        e.body.innerHTML = "",
        e.heading.innerHTML = e.options.months[e.currentMonth] + " " + e.currentYear;
        for (var r = 1, a = "", s = 0; s < 6; s++)
            for (var i = 0; i < 7; i++)
                if (0 === s && i < n)
                    a += "<li></li>";
                else {
                    if (r > h(e.currentYear, e.currentMonth))
                        break;
                    var o = "",
                        d = "-1";
                    r === e.currentDay && (d = "0"),
                    e.dateSelected[0] || e.dateSelected[1] || g() != e.currentMonth || p() != e.currentYear || r != u() || (o += " date-picker__date--today"),
                    e.dateSelected[0] && r === e.selectedDay[0] && e.currentYear === e.selectedYear[0] && e.currentMonth === e.selectedMonth[0] && (o = o + "  " + e.selectedStartClass),
                    e.dateSelected[1] && r === e.selectedDay[1] && e.currentYear === e.selectedYear[1] && e.currentMonth === e.selectedMonth[1] && (o = o + "  " + e.selectedEndClass),
                    a = a + "<li><button class=\"date-picker__date" + o + " js-date-picker__date\" tabindex=\"" + d + "\">" + r + "</button></li>",
                    r++;
                }
        if (e.body.innerHTML = a, e.pickerVisible || e.datePicker.classList.add("date-picker--is-visible"), e.pickerVisible = !0, t || e.body.querySelector("button[tabindex=\"0\"]").focus(), k(e), e.dateSelected[1]) {
            var l = e.element.getElementsByClassName("js-date-picker__date--range-end");
            if (0 < l.length)
                x(e, l[0]);
            else if (function(e) {
                var t = !1,
                    n = !1;
                e.currentYear < e.selectedYear[1] ? t = !0 : e.currentYear == e.selectedYear[1] && e.currentMonth <= e.selectedMonth[1] && (t = !0);
                e.currentYear > e.selectedYear[0] ? n = !0 : e.currentYear == e.selectedYear[0] && e.currentMonth >= e.selectedMonth[0] && (n = !0);
                return t && n;
            }(e)) {
                var c = e.element.getElementsByClassName("js-date-picker__date");
                x(e, c[c.length - 1]);
            }
        }
        f(e, !0);
    }
    function f(e, t) {
        e.triggerLabelWrapper.length < 1 || e.triggerLabelWrapper[0].children.length < 2 || (t ? (e.triggerLabelWrapper[0].children[0].classList.add("hide"), e.triggerLabelWrapper[0].children[1].classList.remove("hide"), Y(e)) : e.dateSelected[0] || e.dateSelected[1] || (e.triggerLabelWrapper[0].children[1].classList.add("hide"), e.triggerLabelWrapper[0].children[0].classList.remove("hide")));
    }
    function c(e) {
        e.datePicker.classList.remove("date-picker--is-visible"),
        e.pickerVisible = !1,
        e.firstFocusable = !1,
        e.lastFocusable = !1,
        e.trigger && e.trigger.setAttribute("aria-expanded", "false"),
        document.activeElement.closest(".js-date-picker") && e.trigger.focus(),
        f(e, !1);
    }
    function y(e, t, n) {
        var r = new Date(e, t, n).getDay() - 1;
        return r < 0 && (r = 6), r;
    }
    function b(e, t) {
        var n = [];
        return n[e.dateIndexes[0]] = m(e.selectedDay[t]), n[e.dateIndexes[1]] = m(e.selectedMonth[t] + 1), n[e.dateIndexes[2]] = e.selectedYear[t], n[0] + e.options.dateSeparator + n[1] + e.options.dateSeparator + n[2];
    }
    function d(e, t) {
        var n = t.split(e.options.dateSeparator);
        return !(n.length < 3) && n[e.dateIndexes[2]] + "-" + n[e.dateIndexes[1]] + "-" + n[e.dateIndexes[0]];
    }
    function m(e) {
        return e < 10 ? "0" + e : e;
    }
    function v(e, t) {
        var n = h(t.currentYear, t.currentMonth);
        if (n < e)
            t.currentDay = e - n,
            i(t, !1),
            D(t);
        else if (e < 1) {
            var r = 0 == t.currentMonth ? 11 : t.currentMonth - 1;
            t.currentDay = h(t.currentYear, r) + e,
            o(t, !1),
            D(t);
        } else {
            t.currentDay = e,
            t.body.querySelector("button[tabindex=\"0\"]").setAttribute("tabindex", "-1");
            for (var a = t.body.getElementsByTagName("button"), s = 0; s < a.length; s++)
                if (a[s].textContent == t.currentDay) {
                    a[s].setAttribute("tabindex", "0"),
                    a[s].focus();
                    break;
                }
            k(t),
            D(t);
        }
    }
    function k(e) {
        var t = e.datePicker.querySelectorAll("[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [tabindex]:not([tabindex=\"-1\"]), [contenteditable], audio[controls], video[controls], summary");
        !function(e, t) {
            for (var n = 0; n < e.length; n++)
                if ((e[n].offsetWidth || e[n].offsetHeight || e[n].getClientRects().length) && "-1" != e[n].getAttribute("tabindex"))
                    return t.firstFocusable = e[n];
        }(t, e),
        function(e, t) {
            for (var n = e.length - 1; 0 <= n; n--)
                if ((e[n].offsetWidth || e[n].offsetHeight || e[n].getClientRects().length) && "-1" != e[n].getAttribute("tabindex"))
                    return t.lastFocusable = e[n];
        }(t, e);
    }
    function C(e) {
        if (e.trigger) {
            var t = "";
            e.selectedYear[0] && e.selectedMonth[0] && e.selectedDay[0] && (t = t + ", start date selected is " + new Date(e.selectedYear[0], e.selectedMonth[0], e.selectedDay[0]).toDateString()),
            e.selectedYear[1] && e.selectedMonth[1] && e.selectedDay[1] && (t = t + ", end date selected is " + new Date(e.selectedYear[1], e.selectedMonth[1], e.selectedDay[1]).toDateString()),
            e.trigger.setAttribute("aria-label", e.triggerLabel + t);
        }
    }
    function _(e) {
        0 < e.dateValueStartEl.length && w(e, 0, e.dateValueStartEl[0], e.dateValueStartElLabel),
        0 < e.dateValueEndEl.length && w(e, 1, e.dateValueEndEl[0], e.dateValueEndElLabel);
    }
    function w(e, t, n, r) {
        e.selectedYear[t] && !1 !== e.selectedMonth[t] && e.selectedDay[t] ? n.textContent = b(e, t) : n.textContent = r;
    }
    function E(e) {
        var t = !1;
        e.dateSelected[0] && !e.dateSelected[1] && (t = "Start date selected is " + new Date(e.selectedYear[0], e.selectedMonth[0], e.selectedDay[0]).toDateString() + ", select end date"),
        t && (e.srLiveReagionM.textContent = t);
    }
    function L(e, t) {
        e.mouseMoving || (e.mouseMoving = !0, window.requestAnimationFrame(function() {
            M(e),
            x(e, t),
            j(e),
            e.mouseMoving = !1;
        }));
    }
    function x(e, t) {
        if (t && !S([e.currentYear, e.currentMonth, parseInt(t.textContent)], [e.selectedYear[0], e.selectedMonth[0], e.selectedDay[0]]))
            if (t.classList.contains("js-date-picker__date--range-start"))
                t.classList.add("date-picker__date--range-start");
            else {
                t.classList.contains("js-date-picker__date--range-end") || t.classList.add(e.inBetweenClass);
                var n = t.closest("li").previousElementSibling;
                if (n) {
                    var r = n.querySelector("button");
                    r && x(e, r);
                }
            }
    }
    function M(e) {
        for (var t = e.element.getElementsByClassName(e.inBetweenClass); t[0];)
            t[0].classList.remove(e.inBetweenClass);
    }
    function S(e, t) {
        return new Date(e[0], e[1], e[2]) < new Date(t[0], t[1], t[2]);
    }
    function D(e) {
        e.dateSelected[0] && !e.dateSelected[1] && L(e, e.element.querySelector(".js-date-picker__date[tabindex=\"0\"]"));
    }
    function j(e) {
        if (e.dateSelected[0] && 0 == e.datePicker.getElementsByClassName(e.inBetweenClass).length) {
            var t = e.datePicker.getElementsByClassName("date-picker__date--range-start");
            0 < t.length && t[0].classList.remove("date-picker__date--range-start");
        }
    }
    function Y(e) {
        e.datePicker.style.left = "0px",
        e.datePicker.style.right = "auto",
        e.datePicker.getBoundingClientRect().right > window.innerWidth && (e.datePicker.style.left = "auto", e.datePicker.style.right = "0px");
    }
    function A(e, t) {
        var n = t.split(" ");
        e.classList.remove(n[0]),
        1 < n.length && A(e, n.slice(1).join(" "));
    }
    var N = function() {
        var n = {},
            r = !1,
            e = 0,
            t = arguments.length;
        "[object Boolean]" === Object.prototype.toString.call(arguments[0]) && (r = arguments[0], e++);
        for (var a = function(e) {
            for (var t in e)
                Object.prototype.hasOwnProperty.call(e, t) && (r && "[object Object]" === Object.prototype.toString.call(e[t]) ? n[t] = Util.extend(!0, n[t], e[t]) : n[t] = e[t]);
        }; e < t; e++) {
            a(arguments[e]);
        }
        return n;
    };
    e.defaults = {
        element: "",
        months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        dateFormat: "d-m-y",
        dateSeparator: "/"
    },
    window.DateRange = e;
    var B,
        I,
        V = document.getElementsByClassName("js-date-range");
    if (0 < V.length)
        for (var P = 0; P < V.length; P++)
            I = void 0,
            I = {
                element: V[B = P]
            },
            V[B].getAttribute("data-date-format") && (I.dateFormat = V[B].getAttribute("data-date-format")),
            V[B].getAttribute("data-date-separator") && (I.dateSeparator = V[B].getAttribute("data-date-separator")),
            V[B].getAttribute("data-months") && (I.months = V[B].getAttribute("data-months").split(",").map(function(e) {
                return e.trim();
            })),
            new e(I);
}());
