// File#: 1_choice-tags
// Usage: https://codyhouse.co/ds/components/info/choice-tags
(function() {
    var choiceTag = function(e) {
        var s;
        this.element = e,
        this.labels = this.element.getElementsByClassName("js-choice-tag"),
        this.inputs = function(e) {
            for (var t = [], s = 0; s < e.labels.length; s++)
                t.push(e.labels[s].getElementsByTagName("input")[0]);
            return t;
        }(this),
        this.isRadio = "radio" == this.inputs[0].type.toString(),
        this.checkedClass = "choice-tag--checked",
        function(e) {
            for (var t = 0; t < e.inputs.length; t++)
                e.labels[t].classList.toggle(e.checkedClass, e.inputs[t].checked);
        }(this),
        (s = this).element.addEventListener("change", function(e) {
            var t = Array.prototype.indexOf.call(s.inputs, e.target);
            t < 0 || (s.labels[t].classList.toggle(s.checkedClass, e.target.checked), s.isRadio && e.target.checked && function(e, t) {
                for (var s = 0; s < e.labels.length; s++)
                    s != t && e.labels[s].classList.remove(e.checkedClass);
            }(s, t));
        });
    };
    window.ChoiceTags = choiceTag;
    var t = document.getElementsByClassName("js-choice-tags");
    if (0 < t.length)
        for (var s = 0; s < t.length; s++)
            new choiceTag(t[s]);
}());