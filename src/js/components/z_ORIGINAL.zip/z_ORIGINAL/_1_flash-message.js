(function() {
    var e = function(e) {
        this.element = e,
        this.showClass = "flash-message--is-visible",
        this.messageDuration = parseInt(this.element.getAttribute("data-duration")) || 3e3,
        this.triggers = document.querySelectorAll("[aria-controls=\"" + this.element.getAttribute("id") + "\"]"),
        this.temeoutId = null,
        this.isVisible = !1,
        this.initFlashMessage();
    };
    e.prototype.initFlashMessage = function() {
        var s = this;
        if (s.triggers)
            for (var e = 0; e < s.triggers.length; e++)
                s.triggers[e].addEventListener("click", function(e) {
                    e.preventDefault(),
                    s.showFlashMessage();
                });
        s.element.addEventListener("showFlashMessage", function() {
            s.showFlashMessage();
        });
    },
    e.prototype.showFlashMessage = function() {
        var e = this;
        e.element.classList.add(e.showClass),
        e.isVisible = !0,
        e.hideOtherFlashMessages(),
        0 < e.messageDuration && (e.temeoutId = setTimeout(function() {
            e.hideFlashMessage();
        }, e.messageDuration));
    },
    e.prototype.hideFlashMessage = function() {
        this.element.classList.remove(this.showClass),
        this.isVisible = !1,
        clearTimeout(this.temeoutId),
        this.temeoutId = null;
    },
    e.prototype.hideOtherFlashMessages = function() {
        var e = new CustomEvent("flashMessageShown", {
            detail: this.element
        });
        window.dispatchEvent(e);
    },
    e.prototype.checkFlashMessage = function(e) {
        this.isVisible && this.element != e && this.hideFlashMessage();
    },
    window.FlashMessage = e;
    var s,
        t = document.getElementsByClassName("js-flash-message");
    if (0 < t.length) {
        for (var i = [], a = 0; a < t.length; a++)
            s = a,
            i.push(new e(t[s]));
        window.addEventListener("flashMessageShown", function(s) {
            i.forEach(function(e) {
                e.checkFlashMessage(s.detail);
            });
        });
    }
}());
