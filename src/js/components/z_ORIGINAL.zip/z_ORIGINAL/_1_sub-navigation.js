/* eslint-disable no-undef */
// _1_sub-navigation
import { addClass, hasClass, removeClass, toggleClass } from './utils';

(function () {
    var subNav = function (e) {
        var n;
        var t;
        (this.element = e),
            (this.control = this.element.getElementsByClassName('js-subnav__control')),
            (this.navList = this.element.getElementsByClassName('js-subnav__wrapper')),
            (this.closeBtn = this.element.getElementsByClassName('js-subnav__close-btn')),
            (this.firstFocusable = (function (e) {
                if (0 == e.navList.length) return;
                for (
                    var t = e.navList[0].querySelectorAll(
                            '[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, [tabindex]:not([tabindex="-1"]), [contenteditable], audio[controls], video[controls], summary',
                        ),
                        s = !1,
                        n = 0;
                    n < t.length;
                    n++
                )
                    if (t[n].offsetWidth || t[n].offsetHeight || t[n].getClientRects().length) {
                        s = t[n];
                        break;
                    }
                return s;
            })(this)),
            (this.showClass = 'subnav__wrapper--is-visible'),
            (this.collapsedLayoutClass = 'subnav--collapsed'),
            a((t = this)),
            (n = t).element.addEventListener('update-sidenav', function () {
                a(n);
            }),
            0 != n.control.length &&
                0 != n.navList.length &&
                (n.control[0].addEventListener('click', function (e) {
                    var s;
                    var t;
                    (s = n),
                        (t = e).preventDefault(),
                        (s.selectedTrigger = t.target),
                        t.target.setAttribute('aria-expanded', 'true'),
                        addClass(s.navList[0], s.showClass),
                        s.navList[0].addEventListener('transitionend', function e() {
                            s.navList[0].removeEventListener('transitionend', e),
                                s.firstFocusable.focus();
                        });
                }),
                n.element.addEventListener('click', function (e) {
                    (e.target.closest('.js-subnav__close-btn') ||
                        hasClass(e.target, 'js-subnav__wrapper')) &&
                        s(n, e);
                }));
    };
    function s(e, t, s) {
        hasClass(e.navList[0], e.showClass) &&
            (t && t.preventDefault(),
            removeClass(e.navList[0], e.showClass),
            e.selectedTrigger &&
                (e.selectedTrigger.setAttribute('aria-expanded', 'false'),
                s || e.selectedTrigger.focus(),
                (e.selectedTrigger = !1)));
    }
    function a(e) {
        // eslint-disable-next-line no-useless-escape
        var t = getComputedStyle(e.element, ':before')
            .getPropertyValue('content')
            .replace(/\'|"/g, '');
        ('expanded' != t && 'collapsed' != t) ||
            toggleClass(e.element, e.collapsedLayoutClass, 'expanded' != t);
    }
    function u() {
        for (let e = 0; e < i.length; e += 1) i[e].element.dispatchEvent(c);
    }
    var t;
    var n = document.getElementsByClassName('js-subnav');
    var i = [];
    var l = 0;
    if (n.length > 0) {
        for (let o = 0; o < n.length; o += 1) {
            var r = getComputedStyle(n[o], ':before').getPropertyValue('content');
            r && '' != r && 'none' != r && (l += 1), (t = o), i.push(new subNav(n[t]));
        }
        if (l > 0) {
            var d = !1;
            var c = new CustomEvent('update-sidenav');

            window.addEventListener('resize', function () {
                clearTimeout(d), (d = setTimeout(u, 300));
            }),
                window.requestAnimationFrame ? window.requestAnimationFrame(u) : u();
        }
        window.addEventListener('keyup', function (e) {
            if ((e.code && e.code === 27) || (e.key && e.key.toLowerCase() === 'escape')) {
                for (t = 0; t < i.length; t += 1) s(i[t], e);
            }
            if ((e.code && e.code === 9) || (e.key && e.key.toLowerCase() === 'tab')) {
                if (document.activeElement.closest('.js-subnav__wrapper')) return;
                for (t = 0; t < i.length; t += 1) s(i[t], e, !0);
            }
        });
    }
})();
