// File#: utils.js
const uid = Date.now();

/**
 * Verifica si un element té una classe específica.
 *
 * @param {HTMLElement} node - L'element DOM a verificar.
 * @param {string} className - El nom de la classe a buscar.
 * @returns {boolean} - Retorna `true` si l'element té la classe, en cas contrari `false`.
 */
export function hasClass(node, className) {
    return node.classList.contains(className);
}
/**
 * Afegeix una classe a l'element
 *
 * @param {HTMLElement} node - L'element DOM a verificar.
 * @param {string} className - El nom de la classe a buscar o noms separats per espais.
 */
export function addClass(node, className) {
    return className.split(' ').forEach((item) => node.classList.add(item));
}
/**
 * Elimina una classe a l'element
 *
 * @param {HTMLElement} node - L'element DOM a verificar.
 * @param {string} className - El nom de la classe a buscar o noms separats per espais.
 */
export function removeClass(node, className) {
    return className.split(' ').forEach((item) => node.classList.remove(item));
}
/**
 * Alterna una classe CSS en un element si es dona una condició
 *
 * @param {HTMLElement} node - L'element DOM a verificar.
 * @param {string} className - El nom de la classe a buscar.
 * @param {boolean} bool - La condició per a afegir o eliminar la classe.
 */
export function toggleClass(node, className, bool) {
    return ((bool) ? addClass(node, className) : removeClass(node, className));
}
/**
 * Alterna un conjunt de classes CSS en un element.
 *
 * @param {HTMLElement} node - L'element DOM a verificar.
 * @param {string} cls - El nom de la classe a buscar o noms separats per cometes.
 */
export function toggleClasses(node, ...cls){
    cls.map((c) => node.classList.toggle(c));
}
/**
 * Show element
 *
 * @param {HTMLElement} element
 */
export function show(element) {
    element.style.display = 'block';
}
/**
 * Hide element
 *  *
 * @param {HTMLElement} element
 */
export function hide(element) {
    element.style.display = 'none';
}
export function setAttributes(el, attrs) {
    for (const key in attrs) {
        el.setAttribute(key, attrs[key]);
    }
}
export function getIndexInArray(array, el) {
    return Array.prototype.indexOf.call(array, el);
}
export function moveFocus(element) {
    if (!element) { element = document.getElementsByTagName('body')[0]; }
    element.focus();
    if (document.activeElement !== element) {
        element.setAttribute('tabindex', '-1');
        element.focus();
    }
}
export function getChildrenByClassName(el, className) {
    var { children } = el;
    var childrenByClass = [];
    for (let i = 0; i < children.length; i += 1) {
        if (hasClass(children[i], className)) childrenByClass.push(children[i]);
    }
    return childrenByClass;
}
export function scrollTo(final, duration, cb, scrollEl) {
    var element = scrollEl || window;
    var start = element.scrollTop || document.documentElement.scrollTop;
    var currentTime = null;
    if (!scrollEl) start = window.scrollY || document.documentElement.scrollTop;

    const animateScroll = function (timestamp) {
        if (!currentTime) currentTime = timestamp;
        let progress = timestamp - currentTime;
        if (progress > duration) progress = duration;
        const val = Math.easeInOutQuad(progress, start, final - start, duration);
        element.scrollTo(0, val);
        if (progress < duration) {
            window.requestAnimationFrame(animateScroll);
        } else {
            cb && cb();
        }
    };
    window.requestAnimationFrame(animateScroll);
}
export function cssSupports(property, value) {
    return CSS.supports(property, value);
}
export function cssTransform(node, translate = '') {
    if (translate === '') {
        node.style.webkitTransform = '';
        node.style.MozTransform = '';
        node.style.msTransform = '';
        node.style.OTransform = '';
        node.style.transform = '';
        return false;
    }
    node.style.webkitTransform = translate;
    node.style.MozTransform = translate;
    node.style.msTransform = translate;
    node.style.OTransform = translate;
    node.style.transform = translate;
}
export function osHasReducedMotion() {
    var e;
    if (!window.matchMedia) return !1;
    e = window.matchMedia('(prefers-reduced-motion: reduce)');
    return !!e && e.matches;
}
/** 
* fusiona un conjunt d'opcions d'usuari amb els valors per defecte del plugin
* https://gomakethings.com/vanilla-javascript-version-of-jquery-extend/
**/
export function extend() {
    // Variables
    let extended = {};
    let deep = false;
    let i = 0;
    let length = arguments.length;

    // Check if a deep merge
    if (Object.prototype.toString.call(arguments[0]) === '[object Boolean]') {
        deep = arguments[0];
        i += 1;
    }

    // Merge the object into the extended object
    // let merge = (obj) => {
    let merge = function (obj) {
        for (let prop in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, prop)) {
                // If deep merge and property is an object, merge properties
                if (deep && Object.prototype.toString.call(obj[prop]) === '[object Object]') {
                    extended[prop] = extend(true, extended[prop], obj[prop]);
                } else {
                    extended[prop] = obj[prop];
                }
            }
        }
    };

    // Loop through each object and conduct a merge
    for (; i < length; i += 1) {
        let obj = arguments[i];
        merge(obj);
    }

    return extended;
}
/**
 * Obté l'element més proper
 *
 * @param {HTMLElement} elem - L'element DOM a verificar.
 * @param {string} selector - El nom de la classe a buscar.
 */
export function closest(elem, selector) {
    while (elem !== document.body) {
        elem = elem.parentElement;
        if (!elem) {
            return false;
        }
        const matches = typeof elem.matches == 'function' ? elem.matches(selector) : elem.msMatchesSelector(selector);

        if (matches) {
            return elem;
        }
    }
}
/**
 * Each
 *
 * @param {mixed} node list, array, object
 * @param {function} callback
 */
export function each(collection, callback) {
    if (isNode(collection) || collection === window || collection === document) {
        collection = [collection];
    }
    if (!isArrayLike(collection) && !isObject(collection)) {
        collection = [collection];
    }
    if (size(collection) == 0) {
        return;
    }

    if (isArrayLike(collection) && !isObject(collection)) {
        let l = collection.length,
            i = 0;
        for (; i < l; i++) {
            if (callback.call(collection[i], collection[i], i, collection) === false) {
                break;
            }
        }
    } else if (isObject(collection)) {
        for (let key in collection) {
            if (has(collection, key)) {
                if (callback.call(collection[key], collection[key], key, collection) === false) {
                    break;
                }
            }
        }
    }
}
/**
 * Obté els esdeveniments del node
 * retorna els esdeveniments del node i opcionalment
 * comprova si el node ja té un esdeveniment específic
 * per evitar callbacks duplicats
 *
 * @param {node} node
 * @param {string} name nom de l'esdeveniment
 * @param {object} fn callback
 * @returns {object}
 */
export function getNodeEvents(node, name = null, fn = null) {
    const cache = (node[uid] = node[uid] || []);
    const data = { all: cache, evt: null, found: null };
    if (name && fn && size(cache) > 0) {
        each(cache, (cl, i) => {
            if (cl.eventName == name && cl.fn.toString() == fn.toString()) {
                data.found = true;
                data.evt = i;
                return false;
            }
        });
    }
    return data;
}
/**
 * Afegeix un esdeveniment
 * Afegeix un listener d'esdeveniments
 *
 * @param {string} eventName - El nom de l'esdeveniment.
 * @param {object} detalls - Els detalls de l'esdeveniment.
 */
export function addEvent(eventName, { onElement, withCallback, avoidDuplicate = true, once = false, useCapture = false } = {}, thisArg) {
    let element = onElement || [];
    if (isString(element)) {
        element = document.querySelectorAll(element);
    }

    function handler(event) {
        if (isFunction(withCallback)) {
            withCallback.call(thisArg, event, this);
        }
        if (once) {
            handler.destroy();
        }
    }
    handler.destroy = function () {
        each(element, (el) => {
            const events = getNodeEvents(el, eventName, handler);
            if (events.found) {
                events.all.splice(events.evt, 1);
            }
            if (el.removeEventListener) {
                el.removeEventListener(eventName, handler, useCapture);
            }
        });
    };
    each(element, (el) => {
        const events = getNodeEvents(el, eventName, handler);
        if ((el.addEventListener && avoidDuplicate && !events.found) || !avoidDuplicate) {
            el.addEventListener(eventName, handler, useCapture);
            events.all.push({ eventName: eventName, fn: handler });
        }
    });
    return handler;
}
/**
 * Espera fins que
 * espera fins que totes les validacions estiguin passades
 *
 * @param {function} check
 * @param {function} onComplete
 * @param {number} delay
 * @param {number} timeout
 */
export function waitUntil(check, onComplete, delay, timeout) {
    if (check()) {
        onComplete();
        return;
    }

    if (!delay) {
        delay = 100;
    }
    let timeoutPointer;
    let intervalPointer = setInterval(() => {
        if (!check()) {
            return;
        }
        clearInterval(intervalPointer);
        if (timeoutPointer) {
            clearTimeout(timeoutPointer);
        }
        onComplete();
    }, delay);
    if (timeout) {
        timeoutPointer = setTimeout(() => {
            clearInterval(intervalPointer);
        }, timeout);
    }
}
/**
 * Injecta l'API de vídeos
 * utilitzat per al reproductor de vídeo
 *
 * @param {string} url
 * @param {function} callback
 */
export function injectAssets(url, waitFor, callback) {
    if (isNil(url)) {
        console.error('Inject assets error');
        return;
    }
    if (isFunction(waitFor)) {
        callback = waitFor;
        waitFor = false;
    }

    if (isString(waitFor) && waitFor in window) {
        if (isFunction(callback)) {
            callback();
        }
        return;
    }

    let found;

    if (url.indexOf('.css') !== -1) {
        found = document.querySelectorAll('link[href="' + url + '"]');
        if (found && found.length > 0) {
            if (isFunction(callback)) {
                callback();
            }
            return;
        }

        const head = document.getElementsByTagName('head')[0];
        const headStyles = head.querySelectorAll('link[rel="stylesheet"]');
        const link = document.createElement('link');

        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = url;
        link.media = 'all';

        if (headStyles) {
            head.insertBefore(link, headStyles[0]);
        } else {
            head.appendChild(link);
        }
        if (isFunction(callback)) {
            callback();
        }
        return;
    }

    found = document.querySelectorAll('script[src="' + url + '"]');
    if (found && found.length > 0) {
        if (isFunction(callback)) {
            if (isString(waitFor)) {
                waitUntil(
                    () => {
                        return typeof window[waitFor] !== 'undefined';
                    },
                    () => {
                        callback();
                    }
                );
                return false;
            }
            callback();
        }
        return;
    }

    let script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;
    script.onload = () => {
        if (isFunction(callback)) {
            if (isString(waitFor)) {
                waitUntil(
                    () => {
                        return typeof window[waitFor] !== 'undefined';
                    },
                    () => {
                        callback();
                    }
                );
                return false;
            }
            callback();
        }
    };
    document.body.appendChild(script);
}
/**
 * CSS Animations
 *
 * @param {HTMLElement} element
 * @param {string} animation name
 * @param {function} callback
 */
export function animateElement(element, animation = '', callback = false) {
    if (!element || animation === '') {
        return false;
    }
    if (animation === 'none') {
        if (isFunction(callback)) {
            callback();
        }
        return false;
    }
    const animationEnd = whichAnimationEvent();
    const animationNames = animation.split(' ');
    each(animationNames, (name) => {
        addClass(element, 'g' + name);
    });
    addEvent(animationEnd, {
        onElement: element,
        avoidDuplicate: false,
        once: true,
        withCallback: (event, target) => {
            each(animationNames, (name) => {
                removeClass(target, 'g' + name);
            });
            if (isFunction(callback)) {
                callback();
            }
        }
    });
}
/**
 * Return screen size
 * return the current screen dimensions
 *
 * @returns {object}
 */
export function windowSize() {
    return {
        width: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
        height: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight
    };
}
/**
 * Determine animation events
 */
export function whichAnimationEvent() {
    let t,
        el = document.createElement('fakeelement');
    let animations = {
        animation: 'animationend',
        OAnimation: 'oAnimationEnd',
        MozAnimation: 'animationend',
        WebkitAnimation: 'webkitAnimationEnd'
    };
    for (t in animations) {
        if (el.style[t] !== undefined) {
            return animations[t];
        }
    }
}
/**
 * Determine transition events
 */
export function whichTransitionEvent() {
    let t,
        el = document.createElement('fakeelement');

    const transitions = {
        transition: 'transitionend',
        OTransition: 'oTransitionEnd',
        MozTransition: 'transitionend',
        WebkitTransition: 'webkitTransitionEnd'
    };

    for (t in transitions) {
        if (el.style[t] !== undefined) {
            return transitions[t];
        }
    }
}
export async function endTransition(target) {
    let t;
    const transitions = {
        // "animation": "animationend",
        // "OAnimation": "oAnimationEnd",
        // "MozAnimation": "animationend",
        // "WebkitAnimation": "webkitAnimationEnd",
        "transition": "transitionend",
        "OTransition": "oTransitionEnd",
        "MozTransition": "transitionend",
        "WebkitTransition": "webkitTransitionEnd"
    };
    for (t in transitions) {
        if (target.style[t] !== undefined) {
            return new Promise((resolve) => {
                target.addEventListener(transitions[t], resolve, { once: true });
            });
        }
    }
}
/**
 * Crea un element iframe
 *
 * @param {string} url
 * @param {number} width
 * @param {number} height
 * @param {function} callback - The function to be called once the iframe is loaded.
 */
export function createIframe(config) {
    let { url, allow, callback, appendTo } = config;
    let iframe = document.createElement('iframe');
    iframe.className = 'vimeo-video gvideo';
    iframe.src = url;
    iframe.style.width = '100%';
    iframe.style.height = '100%';

    if (allow) {
        iframe.setAttribute('allow', allow);
    }
    iframe.onload = function () {
        iframe.onload = null;
        addClass(iframe, 'node-ready');
        if (isFunction(callback)) {
            callback();
        }
    };

    if (appendTo) {
        appendTo.appendChild(iframe);
    }
    return iframe;
}
/**
 * Crea un fragment de document
 *
 * @param {string} html - El codi HTML.
 */
export function createHTML(htmlStr) {
    let frag = document.createDocumentFragment(),
        temp = document.createElement('div');
    temp.innerHTML = htmlStr;
    while (temp.firstChild) {
        frag.appendChild(temp.firstChild);
    }
    return frag;
}
export function isMobile() {
    return 'navigator' in window && window.navigator.userAgent.match(/(iPad)|(iPhone)|(iPod)|(Android)|(PlayBook)|(BB10)|(BlackBerry)|(Opera Mini)|(IEMobile)|(webOS)|(MeeGo)/i);
}
export function isTouch() {
    return isMobile() !== null || document.createTouch !== undefined || 'ontouchstart' in window || 'onmsgesturechange' in window || navigator.msMaxTouchPoints;
}
export function isFunction(f) {
    return typeof f === 'function';
}
export function isString(s) {
    return typeof s === 'string';
}
export function isNode(el) {
    return !!(el && el.nodeType && el.nodeType == 1);
}
export function isArray(ar) {
    return Array.isArray(ar);
}
export function isArrayLike(ar) {
    return ar && ar.length && isFinite(ar.length);
}
export function isObject(o) {
    let type = typeof o;
    return type === 'object' && o != null && !isFunction(o) && !isArray(o);
}
export function isNil(o) {
    return o == null;
}
export function has(obj, key) {
    return obj !== null && hasOwnProperty.call(obj, key);
}
export function size(o) {
    if (isObject(o)) {
        if (o.keys) {
            return o.keys().length;
        }
        let l = 0;
        for (let k in o) {
            if (has(o, k)) {
                l++;
            }
        }
        return l;
    } else {
        return o.length;
    }
}
export function isNumber(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

Math.easeInOutQuad = function (t, b, c, d) {
    t /= d/2;
    if (t < 1) return c/2*t*t + b;
    t--;
    return -c/2 * (t*(t-2) - 1) + b;
};

Math.easeInQuart = function(t, b, c, d) {
    t /= d;
    return c * t * t * t * t + b;
};

Math.easeOutQuart = function(t, b, c, d) {
    t /= d;
    t--;
    return -c * (t * t * t * t - 1) + b;
};

Math.easeInOutQuart = function(t, b, c, d) {
    t /= d / 2;
    if (t < 1)
        return c / 2 * t * t * t * t + b;
    t -= 2;
    return -c / 2 * (t * t * t * t - 2) + b;
};

Math.easeOutElastic = function(t, b, c, d) {
    var s = 1.70158;
    var p = d * 0.7;
    var a = c;
    if (t == 0)
        return b;
    if ((t /= d) == 1)
        return b + c;
    if (!p)
        p = d * .3;
    if (a < Math.abs(c)) {
        a = c;
        s = p / 4;
    }
    else
        s = p / (2 * Math.PI) * Math.asin(c / a);
    return a * Math.pow(2, -10 * t) * Math.sin((t * d - s) * (2 * Math.PI) / p) + c + b;
};
