// _1_table-of-contents
// https://codepen.io/cgurski/pen/qBrNrPo?editors=0010
// https://codepen.io/cuquet/pen/oNQGbvm?editors=1010
import * as Util from '../utils.js';

document.addEventListener('DOMContentLoaded', function() {
    // listen to window scroll -> reset clickScrolling property
    var scrollId = false;
    var resizeId = false;
    TableOfContents();
    const tocs = document.getElementsByClassName('js-toc');
    const tocsArray = [];
    if (tocs.length > 0) {
        for (let i = 0; i < tocs.length; i += 1) {
            (function() {
                tocsArray.push(new Toc(tocs[i])); // tocs[i].classList.add('position-sticky@md');
            }(i));
        }

        // listen to window scroll -> reset clickScrolling property
        // var scrollId = false;
        // var resizeId = false;
        // var scrollEvent = new CustomEvent('toc-scroll');
        // var resizeEvent = new CustomEvent('toc-resize');

        window.addEventListener('scroll', function() {
            clearTimeout(scrollId);
            scrollId = setTimeout(doneScrolling, 100);
        });

        window.addEventListener('resize', function() {
            clearTimeout(resizeId);
            scrollId = setTimeout(doneResizing, 100);
        });
    }
    function doneScrolling() {
        var scrollEvent = new CustomEvent('toc-scroll');
        for (let i = 0; i < tocsArray.length; i += 1) {
            (function() {
                tocsArray[i].element.dispatchEvent(scrollEvent);
            }(i));
        }
    }

    function doneResizing() {
        var resizeEvent = new CustomEvent('toc-resize');
        for (let i = 0; i < tocsArray.length; i += 1) {
            (function() {
                tocsArray[i].element.dispatchEvent(resizeEvent);
            }(i));
        }
    }
});

function TableOfContents(container, output) {
    var toc = '';
    var level = 0;
    var prevlevel = 0;
    container = document.querySelector(container) || document.querySelector('.toc-content');
    if (container) {
        const headingsraw = container.querySelectorAll('h1, h2, h3, h4, h5');
        const headings = Array.prototype.slice.call(headingsraw, 0).filter(function(el) {
            return !(el.classList.contains('toc-skip'));
        });
        output = output || '.toc__nav';

        if (headings.length > 0) {
            toc += '<ul class="toc__list js-toc__list"><li class="toc__label">En aquest article</li>';
            // Recorre els encapçalaments NodeList
            for (let i = 0; i <= headings.length - 1; i += 1) {
                // Set the ID to the header text, all lower case with hyphens instead of spaces. Erase HTML code . 
                // https://stackoverflow.com/questions/3790681/regular-expression-to-remove-html-tags
                // https://regexr.com/7h2ik
                // treu html, barres a la dreta, accents i geminades
                // let id = headings[i].innerHTML.toLowerCase().replace(/<([\w\-/]+)( +[\w\-]+(=(('[^']*')|("[^"]*")))?)* *>/g, "").replace(/ /g, "-"); 
                const id = headings[i].innerHTML.toLowerCase().replace(/(<([\w\-/]+)( +[\w-]+(=(('[^']*')|("[^"]*")))?)* *>)|([/]|[.·]|[à-ü]|[À-Ü])/g, '').replace(/ /g, '-');
                level = parseInt(headings[i].localName.replace('h', '')); // Getting the header a level for hierarchy
                const titleText = headings[i].innerHTML.replace(/<([\w\-/]+)( +[\w\-]+(=(('[^']*')|("[^"]*")))?)* *>/g, ''); // Set the title to the text of the header
                headings[i].setAttribute('id', id); // Set header ID to its text in lower case text with hyphens instead of spaces.
                headings[i].setAttribute('class', 'toc-content__target');
                if (prevlevel > 0 && level > prevlevel) {
                    toc += (new Array(level - prevlevel + 1)).join('<ul class="toc__list">');
                } else if (level < prevlevel) {
                    toc += (new Array(prevlevel - level + 1)).join('</li></ul>');
                } else {
                    toc += (new Array(prevlevel + 1)).join('</li>');
                }
                prevlevel = parseInt(level);
                toc += '<li><a class="toc__link " style="padding-left:calc(var(--space-xs) * ' + level + ')" data-level="' + level + '" href="#' + id + '">' + titleText + '</a>';
            }

            if (prevlevel) {
                toc += (new Array(level + 1)).join('</ul>');
            }
            document.querySelector(output).innerHTML += toc;
        } else {
            const element = document.querySelector('.js-toc');
            element.remove();
        }
    };
}

class Toc {
    constructor(element) {
        this.element = element;
        this.list = this.element.getElementsByClassName('js-toc__list')[0] || null;
        this.anchors = this.list.querySelectorAll('a[href^="#"]');
        this.sections = getSections(this);
        this.controller = this.element.getElementsByClassName('js-toc__control');
        this.controllerLabel = this.element.getElementsByClassName('js-toc__control-label');
        this.content = getTocContent(this);
        this.clickScrolling = false;
        this.intervalID = false;
        this.staticLayoutClass = 'toc--static';
        this.contentStaticLayoutClass = 'toc-content--toc-static';
        this.expandedClass = 'toc--expanded';
        this.isStatic = Util.hasClass(this.element, this.staticLayoutClass);
        this.layout = 'static';
        initToc(this);
    }
}

function getSections(toc) {
    var sections = [];
    var section;
    for (let i = 0; i < toc.anchors.length; i += 1) {
        section = document.getElementById(toc.anchors[i].getAttribute('href').replace('#', ''));
        if (section) sections.push(section);
    }
    return sections;
}

function getTocContent(toc) {
    if (toc.sections.length < 1) return false;
    const content = toc.sections[0].closest('.js-toc-content');
    return content;
}

function initToc(toc) {
    var intersectionObserverSupported;
    var observer;
    for (let i = 0; i < toc.anchors.length; i += 1) {
        toc.anchors[i].classList.add('toc__link', 'js-smooth-scroll');
    }
    checkTocLayour(toc); // switch between mobile and desktop layout

    if (toc.sections.length > 0) {
        // listen for click on anchors
        toc.list.addEventListener('click', function(event) {
            var anchor = event.target.closest('a[href^="#"]');
            if (!anchor) return;
            // reset link apperance
            toc.clickScrolling = true;
            resetAnchors(toc, anchor);
            // close toc if expanded on mobile
            toggleToc(toc, true);
        });

        // check when a new section enters the viewport
        intersectionObserverSupported = ('IntersectionObserver' in window && 'IntersectionObserverEntry' in window && 'intersectionRatio' in window.IntersectionObserverEntry.prototype);
        if (intersectionObserverSupported) {
            observer = new IntersectionObserver(
                function(entries) {
                    entries.forEach(function() {
                        if (!toc.clickScrolling) {
                        // do not update classes if user clicked on a link
                            getVisibleSection(toc);
                        }
                    });
                },
                {
                    threshold: [0, 0.1],
                    rootMargin: '0px 0px -70% 0px'
                }
            );

            for (let i = 0; i < toc.sections.length; i += 1) {
                observer.observe(toc.sections[i]);
            }
        }

        // detect the end of scrolling -> reactivate IntersectionObserver on scroll
        toc.element.addEventListener('toc-scroll', function() {
            toc.clickScrolling = false;
        });
    }

    // custom event emitted when window is resized
    toc.element.addEventListener('toc-resize', function() {
        checkTocLayour(toc);
    });

    // collapsed version only (mobile)
    initCollapsedVersion(toc);
}

function resetAnchors(toc, anchor) {
    if (!anchor) return;
    for (let i = 0; i < toc.anchors.length; i += 1) Util.removeClass(toc.anchors[i], 'toc__link--selected');
    Util.addClass(anchor, 'toc__link--selected');
}

function getVisibleSection(toc) {
    if (toc.intervalID) {
        clearInterval(toc.intervalID);
    }
    toc.intervalID = setTimeout(function() {
        var halfWindowHeight = window.innerHeight / 2;
        var index = -1;
        for (let i = 0; i < toc.sections.length; i += 1) {
            const top = toc.sections[i].getBoundingClientRect().top;
            if (top < halfWindowHeight) index = i;
        }
        if (index > -1) {
            resetAnchors(toc, toc.anchors[index]);
        }
        toc.intervalID = false;
    }, 100);
}

function checkTocLayour(toc) {
    if (toc.isStatic) return;
    // eslint-disable-next-line no-useless-escape
    toc.layout = getComputedStyle(toc.element, ':before').getPropertyValue('content').replace(/\'|"/g, '');
    Util.toggleClass(toc.element, toc.staticLayoutClass, toc.layout === 'static');
    if (toc.content) Util.toggleClass(toc.content, toc.contentStaticLayoutClass, toc.layout === 'static');
}

function initCollapsedVersion(toc) {
    // collapsed version only (mobile)
    if (toc.controller.length < 1) return;

    // toggle nav visibility
    toc.controller[0].addEventListener('click', function() {
        var isOpen = Util.hasClass(toc.element, toc.expandedClass);
        toggleToc(toc, isOpen);
    });

    // close expanded version on esc
    toc.element.addEventListener('keydown', function(event) {
        if (toc.layout === 'static') return;
        if ((event.keyCode && event.keyCode === 27) || (event.key && event.key.toLowerCase() === 'escape')) {
            toggleToc(toc, true);
            toc.controller[0].focus();
        }
    });
}

function toggleToc(toc, bool) {
    // collapsed version only (mobile)
    if (toc.controller.length < 1) return;
    // toggle mobile version
    Util.toggleClass(toc.element, toc.expandedClass, !bool);
    bool ? toc.controller[0].removeAttribute('aria-expanded') : toc.controller[0].setAttribute('aria-expanded', 'true');
    if (!bool && toc.anchors.length > 0) {
        toc.anchors[0].focus();
    }
}
