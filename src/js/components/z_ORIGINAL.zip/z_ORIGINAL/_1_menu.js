// _1_menu.js
(function() {
    var n = function(e) {
        this.element = e,
        this.elementId = this.element.getAttribute("id"),
        this.menuItems = this.element.getElementsByClassName("js-menu__content"),
        this.trigger = document.querySelectorAll("[aria-controls=\"" + this.elementId + "\"]"),
        this.selectedTrigger = !1,
        this.menuIsOpen = !1,
        this.initMenu(),
        this.initMenuEvents();
    };
    function s(e) {
        e.focus(),
        document.activeElement !== e && (e.setAttribute("tabindex", "-1"), e.focus());
    }
    n.prototype.initMenu = function() {
        for (var e = 0; e < this.trigger.length; e++)
            this.trigger[e].setAttribute("aria-expanded", "false"),
            this.trigger[e].setAttribute("aria-haspopup", "true");
        for (e = 0; e < this.menuItems.length; e++)
            this.menuItems[e].setAttribute("tabindex", "0");
    },
    n.prototype.initMenuEvents = function() {
        for (var n = this, e = 0; e < this.trigger.length; e++)
            !function(t) {
                n.trigger[t].addEventListener("click", function(e) {
                    e.preventDefault(),
                    n.element.classList.contains("menu--is-visible") && n.selectedTrigger != n.trigger[t] && n.toggleMenu(!1, !1),
                    n.selectedTrigger = n.trigger[t],
                    n.toggleMenu(!n.element.classList.contains("menu--is-visible"), !0);
                });
            }(e);
        this.element.addEventListener("keydown", function(e) {
            e.target.classList.contains("js-menu__content") && (e.keyCode && 40 == e.keyCode || e.key && "arrowdown" == e.key.toLowerCase() ? n.navigateItems(e, "next") : (e.keyCode && 38 == e.keyCode || e.key && "arrowup" == e.key.toLowerCase()) && n.navigateItems(e, "prev"));
        });
    },
    n.prototype.toggleMenu = function(e, t) {
        var n = this;
        this.element.classList.toggle("menu--is-visible", e),
        // eslint-disable-next-line no-cond-assign
        (this.menuIsOpen = e) ? (this.selectedTrigger.setAttribute("aria-expanded", "true"), s(this.menuItems[0]), this.element.addEventListener("transitionend", function() {
            s(n.menuItems[0]);
        }, {
            once: !0
        }), this.positionMenu(), this.selectedTrigger.classList.add("menu-control--active")) : this.selectedTrigger && (this.selectedTrigger.setAttribute("aria-expanded", "false"), t && s(this.selectedTrigger), this.selectedTrigger.classList.remove("menu-control--active"), this.selectedTrigger = !1);
    },
    n.prototype.positionMenu = function() {
        var n = this.selectedTrigger.getBoundingClientRect(),
            i = window.innerHeight - n.bottom < n.top,
            s = n.left,
            o = window.innerWidth - n.right,
            r = window.innerWidth < n.left + this.element.offsetWidth,
            c = r ? "right: " + o + "px;" : "left: " + s + "px;",
            u = i ? "bottom: " + (window.innerHeight - n.top) + "px;" : "top: " + n.bottom + "px;";
        r && o + this.element.offsetWidth > window.innerWidth && (c = "left: " + parseInt((window.innerWidth - this.element.offsetWidth) / 2) + "px;");
        var l = i ? n.top - 20 : window.innerHeight - n.bottom - 20;
        this.element.setAttribute("style", c + u + "max-height:" + Math.floor(l) + "px;");
    },
    n.prototype.navigateItems = function(e, t) {
        e.preventDefault();
        var n = Array.prototype.indexOf.call(this.menuItems, e.target),
            i = "next" == t ? n + 1 : n - 1;
        i < 0 && (i = this.menuItems.length - 1),
        i > this.menuItems.length - 1 && (i = 0),
        s(this.menuItems[i]);
    },
    n.prototype.checkMenuFocus = function() {
        var e = document.activeElement.closest(".js-menu");
        e && this.element.contains(e) || this.toggleMenu(!1, !1);
    },
    n.prototype.checkMenuClick = function(e) {
        this.element.contains(e) || e.closest("[aria-controls=\"" + this.elementId + "\"]") || this.toggleMenu(!1);
    },
    window.Menu = n;
    var i = document.getElementsByClassName("js-menu");
    if (0 < i.length) {
        for (var o = [], r = [], e = 0; e < i.length; e++)
            !function(e) {
                o.push(new n(i[e]));
                var t = i[e].getAttribute("data-scrollable-element");
                t && !r.includes(t) && r.push(t);
            }(e);
        window.addEventListener("keyup", function(e) {
            e.code && 9 == e.code || e.key && "tab" == e.key.toLowerCase() ? o.forEach(function(e) {
                e.checkMenuFocus();
            }) : (e.code && 27 == e.code || e.key && "escape" == e.key.toLowerCase()) && o.forEach(function(e) {
                e.toggleMenu(!1, !1);
            });
        }),
        window.addEventListener("click", function(t) {
            o.forEach(function(e) {
                e.checkMenuClick(t.target);
            });
        }),
        window.addEventListener("resize", function() {
            o.forEach(function(e) {
                e.toggleMenu(!1, !1);
            });
        }),
        window.addEventListener("scroll", function() {
            o.forEach(function(e) {
                e.menuIsOpen && e.toggleMenu(!1, !1);
            });
        });
        for (var t = 0; t < r.length; t++) {
            var c = document.querySelector(r[t]);
            c && c.addEventListener("scroll", function() {
                o.forEach(function(e) {
                    e.menuIsOpen && e.toggleMenu(!1, !1);
                });
            });
        }
    }
}());