//Newsletter Input
(!function() {
    var NewsInput = function(e) {
        this.options = s(NewsInput.defaults, e),
        this.element = this.options.element,
        this.input = this.element.getElementsByClassName("js-news-form__input"),
        this.button = this.element.getElementsByClassName("js-news-form__btn"),
        this.submitting = false,
        function(o) {
            if (o.input.length < 1 || o.input.button < 1)
                return;
            o.input[0].addEventListener("input", function() {
                var t,
                    n,
                    s,
                    i;
                o.element.classList.remove("news-form--success", "news-form--error"),
                n = (t = o).input[0].value,
                s = n.indexOf("@"),
                i = n.lastIndexOf("."),
                1 <= s && s + 2 <= i && i < n.length - 1 ? (t.element.classList.add("news-form--enabled"), t.button[0].removeAttribute("disabled")) : (t.element.classList.remove("news-form--enabled"), t.button[0].setAttribute("disabled", true));
            }),
            o.element.addEventListener("submit", function(e) {
                e.preventDefault(),
                o.submitting || (o.submitting = true, o.response = false, o.element.classList.add("news-form--loading", "news-form--circle-loop"), o.element.addEventListener("animationend", function e() {
                    o.response ? (o.element.removeEventListener("animationend", e), n(o, o.response)) : (o.element.classList.remove("news-form--circle-loop"), o.element.offsetWidth, o.element.classList.add("news-form--circle-loop"));
                }), o.options.submit(o.input[0].value, function(e) {
                    o.response = e,
                    o.submitting = false,
                    n(o, e);
                }));
            });
        }(this);
    };
    function n(e, t) {
        e.element.classList.remove("news-form--loading", "news-form--circle-loop"),
        "success" == t ? e.element.classList.add("news-form--success") : e.element.classList.add("news-form--error");
    }
    var s = function() {
        var n = {},
            s = false,
            e = 0,
            t = arguments.length;
        "[object Boolean]" === Object.prototype.toString.call(arguments[0]) && (s = arguments[0], e++);
        for (var i = function(e) {
            for (var t in e)
                // eslint-disable-next-line no-undef
                Object.prototype.hasOwnProperty.call(e, t) && (s && "[object Object]" === Object.prototype.toString.call(e[t]) ? n[t] = Util.extend(true, n[t], e[t]) : n[t] = e[t]);
        }; e < t; e++) {
            i(arguments[e]);
        }
        return n;
    };
    (window.NewsInput = NewsInput).defaults = {
        element: "",
        submit: false
    };
}());